import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { PolicyService, ConsolidatePolicy } from '../services/policy.service';

@Component({
  selector: 'app-consolidate-policy',
  standalone: false,
  templateUrl: './consolidate-policy.component.html',
  styleUrls: ['./consolidate-policy.component.scss']
})
export class ConsolidatePolicyComponent implements OnInit {
  searchForm: FormGroup;
  policies: ConsolidatePolicy[] = [];
  currentPage = 1;
  pageSize = 10;
  totalCount = 0;
  totalPages = 0;
  Math = Math;

  constructor(
    private formBuilder: FormBuilder,
    private policyService: PolicyService,
    private router: Router,
    private datePipe: DatePipe
  ) {
    this.searchForm = this.formBuilder.group({
      policyId: [''],
      appNo: ['']
    });
  }

  ngOnInit(): void {
    this.loadData();
  }

  loadData(): void {
    const formValues = this.searchForm.value;
    this.policyService.getConsolidatePolicy(
      formValues.policyId || undefined,
      formValues.appNo || undefined,
      this.currentPage,
      this.pageSize
    ).subscribe({
      next: (response) => {
        this.policies = response.data;
        this.totalCount = response.totalCount;
        this.totalPages = response.totalPages;
      },
      error: (error) => {
        console.error('Error loading data:', error);
      }
    });
  }

  onSearch(): void {
    this.currentPage = 1;
    this.loadData();
  }

  onReset(): void {
    this.searchForm.reset();
    this.currentPage = 1;
    this.loadData();
  }

  onPageSizeChange(): void {
    this.currentPage = 1;
    this.loadData();
  }

  goToPage(page: number): void {
    if (page >= 1 && page <= this.totalPages && page !== this.currentPage) {
      this.currentPage = page;
      this.loadData();
    }
  }

  getPageNumbers(): number[] {
    const pages: number[] = [];
    const startPage = Math.max(1, this.currentPage - 2);
    const endPage = Math.min(this.totalPages, this.currentPage + 2);

    for (let i = startPage; i <= endPage; i++) {
      pages.push(i);
    }
    return pages;
  }

  viewPolicyDetail(policyId: string): void {
    this.router.navigate(['/policy-detail', policyId]);
  }

  // Helper method untuk format date
  formatDate(date: any): string {
    if (!date) return '-';
    return this.datePipe.transform(date, 'dd/MM/yyyy') || '-';
  }
}
