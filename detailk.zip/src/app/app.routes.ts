import { Routes } from '@angular/router';
import { AuthGuard } from './guards/auth.guard';

export const routes: Routes = [
  { 
    path: '', 
    redirectTo: '/login', 
    pathMatch: 'full' 
  },
  { 
    path: 'login', 
    loadComponent: () => import('./login/login.component').then(c => c.LoginComponent)
  },
  { 
    path: 'dashboard', 
    loadComponent: () => import('./dashboard/dashboard.component').then(c => c.DashboardComponent),
    canActivate: [AuthGuard],
    children: [
      { 
        path: '', 
        loadComponent: () => import('./consolidate-policy/consolidate-policy.component').then(c => c.ConsolidatePolicyComponent)
      },
      { 
        path: 'consolidate-policy', 
        loadComponent: () => import('./consolidate-policy/consolidate-policy.component').then(c => c.ConsolidatePolicyComponent)
      },
      { 
        path: 'policy-detail/:id', 
        loadComponent: () => import('./policy-detail/policy-detail.component').then(c => c.PolicyDetailComponent)
      }
    ]
  },
  { 
    path: 'consolidate-policy', 
    loadComponent: () => import('./consolidate-policy/consolidate-policy.component').then(c => c.ConsolidatePolicyComponent),
    canActivate: [AuthGuard]
  },
  { 
    path: 'policy-detail/:id', 
    loadComponent: () => import('./policy-detail/policy-detail.component').then(c => c.PolicyDetailComponent),
    canActivate: [AuthGuard]
  },
  { 
    path: '**', 
    redirectTo: '/login' 
  }
];
