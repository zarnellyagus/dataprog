import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ConsolidatePolicyComponent } from './consolidate-policy/consolidate-policy.component';
import { PolicyDetailComponent } from './policy-detail/policy-detail.component';
import { AuthGuard } from './guards/auth.guard';

const routes: Routes = [
  { 
    path: '', 
    redirectTo: '/login', 
    pathMatch: 'full' 
  },
  { 
    path: 'login', 
    component: LoginComponent 
  },
  { 
    path: 'dashboard', 
    component: DashboardComponent,
    canActivate: [AuthGuard],
    children: [
      { 
        path: '', 
        component: ConsolidatePolicyComponent 
      }
    ]
  },
  { 
    path: 'consolidate-policy', 
    component: ConsolidatePolicyComponent,
    canActivate: [AuthGuard]
  },
  { 
    path: 'policy-detail/:id', 
    component: PolicyDetailComponent,
    canActivate: [AuthGuard]
  },
  { 
    path: '**', 
    redirectTo: '/login' 
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    enableTracing: false,
    useHash: false
  })],
  exports: [RouterModule]  // PENTING: Harus export RouterModule
})
export class AppRoutingModule { }
