import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DatePipe } from '@angular/common';
import { PolicyService, PolicyInfo, EPolicy, PolicySummary } from '../services/policy.service';

@Component({
  selector: 'app-policy-detail',
  standalone: false,
  templateUrl: './policy-detail.component.html',
  styleUrls: ['./policy-detail.component.scss']
})
export class PolicyDetailComponent implements OnInit {
  policyId: string = '';
  policyInfo: PolicyInfo | null = null;
  ePolicies: EPolicy[] = [];
  policySummary: PolicySummary | null = null;
  
  // Loading states
  policyInfoLoading = true;
  ePolicyLoading = true;
  policySummaryLoading = true;

  constructor(
    private route: ActivatedRoute,
    private policyService: PolicyService,
    private datePipe: DatePipe
  ) {}

  ngOnInit(): void {
    this.policyId = this.route.snapshot.params['id'];
    this.loadPolicyData();
  }

  loadPolicyData(): void {
    // Load Policy Info
    this.policyService.getPolicyInfo(this.policyId).subscribe({
      next: (data: PolicyInfo) => {
        this.policyInfo = data;
        this.policyInfoLoading = false;
      },
      error: (error) => {
        console.error('Error loading policy info:', error);
        this.policyInfo = null;
        this.policyInfoLoading = false;
      }
    });

    // Load E-Policy Data
    this.policyService.getEPolicy(this.policyId).subscribe({
      next: (data: EPolicy[]) => {
        this.ePolicies = data || [];
        this.ePolicyLoading = false;
      },
      error: (error) => {
        console.error('Error loading e-policy data:', error);
        this.ePolicies = [];
        this.ePolicyLoading = false;
      }
    });

    // Load Policy Summary
    this.policyService.getPolicySummary(this.policyId).subscribe({
      next: (data: PolicySummary) => {
        this.policySummary = data;
        this.policySummaryLoading = false;
      },
      error: (error) => {
        console.error('Error loading policy summary:', error);
        this.policySummary = null;
        this.policySummaryLoading = false;
      }
    });
  }

  /**
   * Format date using DatePipe with null safety
   */
  formatDate(date: any): string {
    if (!date) return '-';
    try {
      return this.datePipe.transform(date, 'dd/MM/yyyy') || '-';
    } catch (error) {
      console.warn('Date formatting error:', error);
      return '-';
    }
  }

  /**
   * Safe getter for policy info string properties
   */
  getPolicyInfoValue(property: keyof PolicyInfo): string {
    if (!this.policyInfo) return '-';
    const value = this.policyInfo[property];
    if (value === null || value === undefined || value === '') return '-';
    return String(value);
  }

  /**
   * Safe getter for policy info date properties
   */
  getPolicyInfoDateValue(property: keyof PolicyInfo): string {
    if (!this.policyInfo) return '-';
    const value = this.policyInfo[property];
    return this.formatDate(value);
  }

  /**
   * Safe getter for policy summary string properties
   */
  getPolicySummaryValue(property: keyof PolicySummary): string {
    if (!this.policySummary) return '-';
    const value = this.policySummary[property];
    if (value === null || value === undefined || value === '') return '-';
    return String(value);
  }

  /**
   * Safe getter for policy summary date properties
   */
  getPolicySummaryDateValue(property: keyof PolicySummary): string {
    if (!this.policySummary) return '-';
    const value = this.policySummary[property];
    return this.formatDate(value);
  }

  /**
   * Safe getter for e-policy string properties
   */
  getEPolicyValue(epolicy: EPolicy | null, property: keyof EPolicy): string {
    if (!epolicy) return '-';
    const value = epolicy[property];
    if (value === null || value === undefined || value === '') return '-';
    return String(value);
  }

  /**
   * Safe getter for e-policy date properties
   */
  getEPolicyDateValue(epolicy: EPolicy | null, property: keyof EPolicy): string {
    if (!epolicy) return '-';
    const value = epolicy[property];
    return this.formatDate(value);
  }

  /**
   * Check if policy info is available
   */
  isPolicyInfoAvailable(): boolean {
    return this.policyInfo !== null;
  }

  /**
   * Check if policy summary is available
   */
  isPolicySummaryAvailable(): boolean {
    return this.policySummary !== null;
  }

  /**
   * Check if e-policy data is available
   */
  isEPolicyAvailable(): boolean {
    return this.ePolicies.length > 0;
  }

  /**
   * Get loading state for policy info
   */
  isPolicyInfoLoading(): boolean {
    return this.policyInfoLoading;
  }

  /**
   * Get loading state for policy summary
   */
  isPolicySummaryLoading(): boolean {
    return this.policySummaryLoading;
  }

  /**
   * Get loading state for e-policy
   */
  isEPolicyLoading(): boolean {
    return this.ePolicyLoading;
  }
}
