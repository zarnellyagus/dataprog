import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';
import { AuthService } from './services/auth.service';

@Component({
  selector: 'app-root',
  standalone: false,
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'CompdtAPI-Angular';
  isLoggedIn = false;
  currentUser: any = null;
  showNavigation = false;
  
  private authSubscription?: Subscription;
  private routerSubscription?: Subscription;

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    // Subscribe to authentication status changes
    this.authSubscription = this.authService.currentUser$.subscribe(user => {
      this.isLoggedIn = !!user;
      this.currentUser = user;
      this.updateNavigationVisibility();
    });

    // Subscribe to router events to update navigation visibility
    this.routerSubscription = this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe((event: NavigationEnd) => {
        this.updateNavigationVisibility();
      });

    // Initialize navigation visibility
    this.updateNavigationVisibility();
  }

  ngOnDestroy(): void {
    if (this.authSubscription) {
      this.authSubscription.unsubscribe();
    }
    if (this.routerSubscription) {
      this.routerSubscription.unsubscribe();
    }
  }

  /**
   * Update navigation visibility based on current route and authentication status
   */
  private updateNavigationVisibility(): void {
    const currentUrl = this.router.url;
    const publicRoutes = ['/login', '/'];
    
    // Hide navigation on public routes or when not logged in
    this.showNavigation = this.isLoggedIn && !publicRoutes.includes(currentUrl);
  }

  /**
   * Handle user logout
   */
  onLogout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  /**
   * Check if current route is login page
   */
  isLoginPage(): boolean {
    return this.router.url === '/login' || this.router.url === '/';
  }

  /**
   * Check if current route is dashboard or protected route
   */
  isDashboardRoute(): boolean {
    const protectedRoutes = ['/dashboard', '/consolidate-policy', '/policy-detail'];
    return protectedRoutes.some(route => this.router.url.startsWith(route));
  }

  /**
   * Get current page title based on route
   */
  getCurrentPageTitle(): string {
    const currentUrl = this.router.url;
    
    if (currentUrl.startsWith('/consolidate-policy')) {
      return 'Consolidate Policy';
    } else if (currentUrl.startsWith('/policy-detail')) {
      return 'Policy Detail';
    } else if (currentUrl.startsWith('/dashboard')) {
      return 'Dashboard';
    }
    
    return 'CompdtAPI System';
  }

  /**
   * Handle navigation errors
   */
  onNavigationError(error: any): void {
    console.error('Navigation error:', error);
    
    // If user is not authenticated, redirect to login
    if (!this.isLoggedIn) {
      this.router.navigate(['/login']);
    }
  }

  /**
   * Get user initials for avatar display
   */
  getUserInitials(): string {
    if (!this.currentUser?.userID) {
      return 'U';
    }
    
    const userID = this.currentUser.userID.toString();
    return userID.substring(0, 2).toUpperCase();
  }

  /**
   * Get company display name
   */
  getCompanyDisplay(): string {
    return this.currentUser?.companyID || 'N/A';
  }

  /**
   * Handle application-wide error
   */
  onAppError(error: any): void {
    console.error('Application error:', error);
  }

  /**
   * Check if sidebar should be shown
   */
  shouldShowSidebar(): boolean {
    return this.showNavigation && this.isDashboardRoute();
  }

  /**
   * Check if header should be shown
   */
  shouldShowHeader(): boolean {
    return this.showNavigation && this.isDashboardRoute();
  }

  /**
   * Navigate to login page
   */
  navigateToLogin(): void {
    this.router.navigate(['/login']);
  }
}
