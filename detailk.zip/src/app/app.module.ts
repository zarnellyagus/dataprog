import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule, DatePipe } from '@angular/common';

// Import routing HARUS setelah RouterModule
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';

// Components
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ConsolidatePolicyComponent } from './consolidate-policy/consolidate-policy.component';
import { PolicyDetailComponent } from './policy-detail/policy-detail.component';

// Services
import { AuthService } from './services/auth.service';
import { PolicyService } from './services/policy.service';

// Guards
import { AuthGuard } from './guards/auth.guard';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    ConsolidatePolicyComponent,
    PolicyDetailComponent
  ],
  imports: [
    BrowserModule,          // HARUS PERTAMA untuk web applications
    CommonModule,           // Untuk *ngIf, *ngFor, pipes
    ReactiveFormsModule,    // Untuk [formGroup]
    FormsModule,           // Untuk [(ngModel)]
    HttpClientModule,      // Untuk HTTP requests
    RouterModule,          // Untuk <router-outlet> dan [routerLink]
    AppRoutingModule       // HARUS TERAKHIR dalam routing imports
  ],
  providers: [
    AuthService,
    PolicyService,
    AuthGuard,
    DatePipe
  ],
  bootstrap: [AppComponent]
})
export class AppModule { 
  constructor() {
    console.log('AppModule loaded with all imports');
  }
}
