import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';

interface Transaction {
  id: string;
  date: Date;
  number: string;
  memo: string;
  contact: string;
  dueDate: Date;
  status: 'Paid' | 'Pending' | 'Overdue';
  remainingAmount: number;
  totalAmount: number;
  tags: string[];
}

@Component({
  selector: 'app-transaction-list',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    MatIconModule
  ],
  templateUrl: './transaction-list.component.html',
  styleUrls: ['./transaction-list.component.css']
})
export class TransactionListComponent implements OnInit {
  // Filter properties
  filterStartDate = '2026-02-18';
  filterEndDate = '2026-02-18';
  filterTransactionType = '';
  searchText = '';

  // Sorting
  sortColumn = '';
  sortDirection: 'asc' | 'desc' = 'asc';

  // Pagination
  currentPage = 1;
  itemsPerPage = 10;
  totalPages = 1;

  // Data
  transactions: Transaction[] = [];
  filteredTransactions: Transaction[] = [];

  ngOnInit(): void {
    this.loadTransactions();
  }

  loadTransactions(): void {
    // Sample data - ganti dengan API call
    this.transactions = [
      {
        id: '1',
        date: new Date('2026-02-15'),
        number: 'TRX-001',
        memo: 'Premium Payment',
        contact: 'John Doe',
        dueDate: new Date('2026-03-15'),
        status: 'Paid',
        remainingAmount: 0,
        totalAmount: 5000000,
        tags: ['Premium', 'Monthly']
      },
      {
        id: '2',
        date: new Date('2026-02-16'),
        number: 'TRX-002',
        memo: 'Policy Renewal',
        contact: 'Jane Smith',
        dueDate: new Date('2026-03-01'),
        status: 'Pending',
        remainingAmount: 3000000,
        totalAmount: 3000000,
        tags: ['Renewal']
      },
      {
        id: '3',
        date: new Date('2026-02-14'),
        number: 'TRX-003',
        memo: 'Claim Payment',
        contact: 'Bob Wilson',
        dueDate: new Date('2026-02-20'),
        status: 'Overdue',
        remainingAmount: 2000000,
        totalAmount: 2000000,
        tags: ['Claim', 'Urgent']
      }
      // Add more sample data...
    ];

    this.filteredTransactions = [...this.transactions];
    this.calculatePagination();
  }

  applyFilter(): void {
    this.filteredTransactions = this.transactions.filter(transaction => {
      // Date filter
      const transactionDate = new Date(transaction.date);
      const startDate = this.filterStartDate ? new Date(this.filterStartDate) : null;
      const endDate = this.filterEndDate ? new Date(this.filterEndDate) : null;

      if (startDate && transactionDate < startDate) return false;
      if (endDate && transactionDate > endDate) return false;

      // Type filter (if you have transaction types)
      // if (this.filterTransactionType && transaction.type !== this.filterTransactionType) {
      //   return false;
      // }

      // Search filter
      if (this.searchText) {
        const searchLower = this.searchText.toLowerCase();
        return (
          transaction.number.toLowerCase().includes(searchLower) ||
          transaction.memo.toLowerCase().includes(searchLower) ||
          transaction.contact.toLowerCase().includes(searchLower) ||
          transaction.status.toLowerCase().includes(searchLower)
        );
      }

      return true;
    });

    this.currentPage = 1;
    this.calculatePagination();
  }

  resetFilter(): void {
    this.filterStartDate = '';
    this.filterEndDate = '';
    this.filterTransactionType = '';
    this.searchText = '';
    this.filteredTransactions = [...this.transactions];
    this.calculatePagination();
  }

  onSearch(): void {
    this.applyFilter();
  }

  sortBy(column: string): void {
    if (this.sortColumn === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumn = column;
      this.sortDirection = 'asc';
    }

    this.filteredTransactions.sort((a, b) => {
      let aValue: any;
      let bValue: any;

      switch (column) {
        case 'date':
          aValue = a.date.getTime();
          bValue = b.date.getTime();
          break;
        case 'number':
          aValue = a.number;
          bValue = b.number;
          break;
        case 'contact':
          aValue = a.contact;
          bValue = b.contact;
          break;
        case 'status':
          aValue = a.status;
          bValue = b.status;
          break;
        default:
          return 0;
      }

      if (aValue < bValue) return this.sortDirection === 'asc' ? -1 : 1;
      if (aValue > bValue) return this.sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
  }

  calculatePagination(): void {
    this.totalPages = Math.ceil(this.filteredTransactions.length / this.itemsPerPage);
  }

  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
    }
  }
}
