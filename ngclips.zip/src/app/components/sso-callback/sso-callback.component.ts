import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-sso-callback',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="loading-container">
      <div class="spinner-wrapper">
        <div class="spinner" *ngIf="!showError"></div>
        <div class="error-icon" *ngIf="showError">⚠️</div>
        <p [class.error]="showError">{{ loadingMessage }}</p>
        <button 
          *ngIf="showError" 
          class="back-button"
          (click)="goToLogin()">
          Back to Login
        </button>
      </div>
    </div>
  `,
  styles: [`
    .loading-container {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      background: linear-gradient(135deg, #0E3846 0%, #1a5568 100%);
      overflow: hidden;
    }

    .spinner-wrapper {
      text-align: center;
      background: white;
      padding: 40px 60px;
      border-radius: 12px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.2);
      min-width: 300px;
    }

    .spinner {
      width: 50px;
      height: 50px;
      margin: 0 auto 20px;
      border: 4px solid #f3f3f3;
      border-top: 4px solid #ECAB23;
      border-radius: 50%;
      animation: spin 1s linear infinite;
    }

    .error-icon {
      font-size: 50px;
      margin-bottom: 20px;
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    p {
      font-size: 16px;
      color: #0E3846;
      margin: 0 0 20px 0;
      font-weight: 500;
      line-height: 1.5;
    }

    p.error {
      color: #e74c3c;
    }

    .back-button {
      padding: 12px 24px;
      background: #ECAB23;
      color: #0E3846;
      border: none;
      border-radius: 6px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      text-transform: uppercase;
    }

    .back-button:hover {
      background: #d89a1f;
      transform: translateY(-2px);
    }
  `]
})
export class SsoCallbackComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private authService = inject(AuthService);
  private router = inject(Router);

  loadingMessage = 'Processing SSO authentication...';
  showError = false;

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      const samlResponse = params['SAMLResponse'];
      
      if (samlResponse) {
        this.loadingMessage = 'Validating SSO credentials...';
        
        this.authService.handleSSOCallback(samlResponse).subscribe({
          next: (response) => {
            this.loadingMessage = 'Authentication successful! Redirecting...';
            setTimeout(() => {
              this.router.navigate(['/dashboard']);
            }, 500);
          },
          error: (error) => {
            console.error('SSO authentication failed:', error);
            this.showError = true;
            this.loadingMessage = 'SSO authentication failed. Please use manual login with username "admin" and password "admin".';
            
            // Auto redirect after 5 seconds
            setTimeout(() => {
              this.goToLogin();
            }, 5000);
          }
        });
      } else {
        console.error('No SAML response in URL');
        this.showError = true;
        this.loadingMessage = 'Invalid SSO response. Please use manual login.';
        
        setTimeout(() => {
          this.goToLogin();
        }, 3000);
      }
    });
  }

  goToLogin(): void {
    this.router.navigate(['/login'], {
      queryParams: { error: 'sso_failed' }
    });
  }
}
