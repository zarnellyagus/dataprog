import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatListModule } from '@angular/material/list';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatMenuModule } from '@angular/material/menu';
import { MatDividerModule } from '@angular/material/divider';
import { Router, RouterModule } from '@angular/router';

interface MenuItem {
  icon?: string;
  label: string;
  route?: string;
  badge?: number;
  children?: MenuItem[];
  expanded?: boolean;
  isHeader?: boolean;
}

// ← TAMBAH INTERFACE TRANSACTION
interface Transaction {
  id: string;
  tanggal: Date;
  nomor: string;
  memo: string;
  kontak: string;
  tglJatuhTempo: Date;
  status: 'Lunas' | 'Pending' | 'Jatuh Tempo';
  sisaTagihan: number;
  total: number;
  tags: string[];
}

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatToolbarModule,
    MatSidenavModule,
    MatIconModule,
    MatButtonModule,
    MatListModule,
    MatProgressBarModule,
    MatMenuModule,
    MatDividerModule,
    RouterModule
  ],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent {
  private router = inject(Router);
  
  sidenavOpened = true;
  activeTab = 'Month';
  
  currentUser = {
    name: 'John Doe',
    email: 'johndoe@example.com',
    avatar: 'account_circle'
  };

  // ← TAMBAH PROPERTIES UNTUK FILTER & TABLE
  filterStartDate = '2026-02-18';
  filterEndDate = '2026-02-18';
  filterTransactionType = '';
  searchText = '';

  sortColumn = '';
  sortDirection: 'asc' | 'desc' = 'asc';

  currentPage = 1;
  itemsPerPage = 10;
  totalPages = 1;

  transactions: Transaction[] = [];
  filteredTransactions: Transaction[] = [];

  activatedCount = 25610;
  pendingCount = 56210;

  menuItems: MenuItem[] = [
    { icon: 'dashboard', label: 'Dashboard', route: '/dashboard' },

    { label: 'Policy & Certificate', isHeader: true },
    { icon: 'list_alt',        label: 'Certificate List', route: '/dashboard/certificate-list' },
    { icon: 'fiber_new',       label: 'New Business',     route: '/dashboard/new-business' },
    { icon: 'verified_user',   label: 'Underwriting',     route: '/dashboard/underwriting' },
    { icon: 'manage_accounts', label: 'Policy Admin',     route: '/dashboard/policy-admin' },

    { label: 'Aktivitas', isHeader: true },
    { icon: 'receipt_long', label: 'Billing', route: '/dashboard/aktivitas/billing' },

    { label: 'Reports', isHeader: true },
    { icon: 'bar_chart', label: 'Reports', route: '/dashboard/reports' }
  ];

  // ← TAMBAH CONSTRUCTOR
  constructor() {
    this.loadTransactions();
  }

  // ← TAMBAH METHOD LOAD TRANSACTIONS
  loadTransactions(): void {
    // Sample data - ganti dengan API call
    this.transactions = [
      {
        id: '1',
        tanggal: new Date('2026-02-15'),
        nomor: 'TRX-2026-001',
        memo: 'Pembayaran Premi Asuransi',
        kontak: 'PT Asuransi Sejahtera',
        tglJatuhTempo: new Date('2026-03-15'),
        status: 'Lunas',
        sisaTagihan: 0,
        total: 5000000,
        tags: ['Premi', 'Bulanan']
      },
      {
        id: '2',
        tanggal: new Date('2026-02-16'),
        nomor: 'TRX-2026-002',
        memo: 'Perpanjangan Polis',
        kontak: 'John Smith',
        tglJatuhTempo: new Date('2026-03-01'),
        status: 'Pending',
        sisaTagihan: 3000000,
        total: 3000000,
        tags: ['Perpanjangan']
      },
      {
        id: '3',
        tanggal: new Date('2026-02-14'),
        nomor: 'TRX-2026-003',
        memo: 'Klaim Asuransi Kesehatan',
        kontak: 'Jane Doe',
        tglJatuhTempo: new Date('2026-02-20'),
        status: 'Jatuh Tempo',
        sisaTagihan: 2000000,
        total: 2000000,
        tags: ['Klaim', 'Urgent']
      },
      {
        id: '4',
        tanggal: new Date('2026-02-17'),
        nomor: 'TRX-2026-004',
        memo: 'Pembayaran Klaim Kecelakaan',
        kontak: 'Bob Wilson',
        tglJatuhTempo: new Date('2026-03-10'),
        status: 'Lunas',
        sisaTagihan: 0,
        total: 10000000,
        tags: ['Klaim']
      },
      {
        id: '5',
        tanggal: new Date('2026-02-18'),
        nomor: 'TRX-2026-005',
        memo: 'Top Up Investasi',
        kontak: 'Alice Brown',
        tglJatuhTempo: new Date('2026-03-05'),
        status: 'Pending',
        sisaTagihan: 5000000,
        total: 5000000,
        tags: ['Investasi', 'Top Up']
      },
      {
        id: '6',
        tanggal: new Date('2026-02-13'),
        nomor: 'TRX-2026-006',
        memo: 'Premi Asuransi Kendaraan',
        kontak: 'PT Asuransi Mobil',
        tglJatuhTempo: new Date('2026-03-13'),
        status: 'Lunas',
        sisaTagihan: 0,
        total: 2500000,
        tags: ['Premi', 'Kendaraan']
      },
      {
        id: '7',
        tanggal: new Date('2026-02-12'),
        nomor: 'TRX-2026-007',
        memo: 'Klaim Rawat Inap',
        kontak: 'Sarah Johnson',
        tglJatuhTempo: new Date('2026-02-25'),
        status: 'Pending',
        sisaTagihan: 8000000,
        total: 8000000,
        tags: ['Klaim', 'Kesehatan']
      },
      {
        id: '8',
        tanggal: new Date('2026-02-11'),
        nomor: 'TRX-2026-008',
        memo: 'Pembayaran Premi Jiwa',
        kontak: 'Michael Chen',
        tglJatuhTempo: new Date('2026-03-11'),
        status: 'Lunas',
        sisaTagihan: 0,
        total: 4500000,
        tags: ['Premi', 'Jiwa']
      }
    ];

    this.filteredTransactions = [...this.transactions];
    this.calculatePagination();
  }

  // ← TAMBAH METHOD NEW BUSINESS
  createNewBusiness(): void {
    console.log('Creating new business...');
    this.router.navigate(['/dashboard/certificate/new-business']);
  }

  // ← TAMBAH METHOD APPLY FILTER
  applyFilter(): void {
    this.filteredTransactions = this.transactions.filter(transaction => {
      const transactionDate = new Date(transaction.tanggal);
      const startDate = this.filterStartDate ? new Date(this.filterStartDate) : null;
      const endDate = this.filterEndDate ? new Date(this.filterEndDate) : null;

      if (startDate && transactionDate < startDate) return false;
      if (endDate && transactionDate > endDate) return false;

      if (this.searchText) {
        const searchLower = this.searchText.toLowerCase();
        return (
          transaction.nomor.toLowerCase().includes(searchLower) ||
          transaction.memo.toLowerCase().includes(searchLower) ||
          transaction.kontak.toLowerCase().includes(searchLower) ||
          transaction.status.toLowerCase().includes(searchLower)
        );
      }

      return true;
    });

    this.currentPage = 1;
    this.calculatePagination();
  }

  // ← TAMBAH METHOD RESET FILTER
  resetFilter(): void {
    this.filterStartDate = '';
    this.filterEndDate = '';
    this.filterTransactionType = '';
    this.searchText = '';
    this.filteredTransactions = [...this.transactions];
    this.calculatePagination();
  }

  // ← TAMBAH METHOD ON SEARCH
  onSearch(): void {
    this.applyFilter();
  }

  // ← TAMBAH METHOD SORT BY
  sortBy(column: string): void {
    if (this.sortColumn === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumn = column;
      this.sortDirection = 'asc';
    }

    this.filteredTransactions.sort((a, b) => {
      let aValue: any;
      let bValue: any;

      switch (column) {
        case 'tanggal':
          aValue = a.tanggal.getTime();
          bValue = b.tanggal.getTime();
          break;
        case 'nomor':
          aValue = a.nomor;
          bValue = b.nomor;
          break;
        case 'kontak':
          aValue = a.kontak;
          bValue = b.kontak;
          break;
        case 'status':
          aValue = a.status;
          bValue = b.status;
          break;
        default:
          return 0;
      }

      if (aValue < bValue) return this.sortDirection === 'asc' ? -1 : 1;
      if (aValue > bValue) return this.sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
  }

  // ← TAMBAH METHOD CALCULATE PAGINATION
  calculatePagination(): void {
    this.totalPages = Math.ceil(this.filteredTransactions.length / this.itemsPerPage);
  }

  // ← TAMBAH METHOD PREVIOUS PAGE
  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  // ← TAMBAH METHOD NEXT PAGE
  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
    }
  }

  // METHODS YANG SUDAH ADA
  logout(): void {
    console.log('=== LOGOUT START ===');
    console.log('Current route:', this.router.url);
    
    try {
      localStorage.clear();
      sessionStorage.clear();
      console.log('✓ Storage cleared');
      
      this.router.navigate(['/login']).then(
        (success) => {
          console.log('✓ Navigation success:', success);
          if (!success) {
            console.warn('Navigation returned false, trying navigateByUrl...');
            this.router.navigateByUrl('/login');
          }
        },
        (error) => {
          console.error('✗ Navigation error:', error);
          window.location.href = '/login';
        }
      );
    } catch (error) {
      console.error('✗ Logout error:', error);
      window.location.href = '/login';
    }
    
    console.log('=== LOGOUT END ===');
  }

  toggleSidenav(): void {
    this.sidenavOpened = !this.sidenavOpened;
  }

  toggleMenuItem(item: MenuItem): void {
    if (item.children) {
      item.expanded = !item.expanded;
    }
  }
}
