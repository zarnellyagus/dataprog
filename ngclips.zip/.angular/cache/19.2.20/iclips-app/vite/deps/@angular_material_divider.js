import {
  MatDivider,
  MatDividerModule
} from "./chunk-XBSN5R5F.js";
import "./chunk-IBYU652R.js";
import "./chunk-32NDN263.js";
import "./chunk-LDAZ76SO.js";
import "./chunk-MVNJMFVL.js";
import "./chunk-GIYX2BAP.js";
import "./chunk-U7YDHSFO.js";
import "./chunk-UGCR7KEQ.js";
import "./chunk-S35MAB2V.js";
export {
  MatDivider,
  MatDividerModule
};
