import { Routes } from '@angular/router';
import { LoginComponent } from './pages/login/login.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { DashboardHomeComponent } from './pages/dashboard-home/dashboard-home.component';
import {DataTableComponent} from './pages/data-table/data-table.component';
import {TransferListComponent} from './pages/transfer-list/transfer-list.component';
import { NewCertificateComponent } from './pages/certificate/new-certificate/new-certificate.component';
import { AuthGuard } from './guards/auth.guard';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'login' },
  { path: 'login', component: LoginComponent },
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [AuthGuard], // tambahkan guard jika perlu
    children: [
    { path: '', component: DashboardHomeComponent },// dashboard-home di kanan
     { path: 'penjualan/datatable', component: DataTableComponent },// dashboard-home di kanan
      { path: 'penjualan/transfer', component: TransferListComponent },// dashboard-home di kanan
      { path: 'certificate/new', component: NewCertificateComponent },
      { path: 'certificate/edit/:id', component: NewCertificateComponent }

     ]
  },
  { path: '**', redirectTo: 'dashboard' }
];