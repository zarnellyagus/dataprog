// src/app/pages/dashboard-home/dashboard-home.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-dashboard-home',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dashboard-home.component.html',
  styleUrls: ['./dashboard-home.component.css']
})
export class DashboardHomeComponent {
  // dummy data, nanti bisa diganti dari API
  produkAktif = 1234;
  pesananBaru = 10;
  pemasok = 89;
  targetTercapai = 45.2; // juta
  persentaseTarget = 92;
}
