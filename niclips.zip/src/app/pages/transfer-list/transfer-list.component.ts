import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { Router } from '@angular/router';

interface Transfer {
  id: string;
  PolicyNo: string;
  CertificateNo: string;
  InsuredId: string;
  InsuredName: string;
  ProgressStatus: string;
  ReceivedDate: string;
  PendingItem: string;
  isFavorite: boolean;
  selected: boolean;
}

@Component({
  selector: 'app-transfer-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './transfer-list.component.html',
  styleUrls: ['./transfer-list.component.css']
})
export class TransferListComponent implements OnInit {

  isSelectOpen: boolean = false;
  selectedOption: string = 'Select Action';

  constructor(private router: Router) {}

 

  transfers: Transfer[] = [];
  filteredData: Transfer[] = [];
  paginatedData: Transfer[] = [];
  
  searchQuery: string = '';
  showFilters: boolean = false;
  isGrouped: boolean = false;
  showFavoritesOnly: boolean = false;
  selectAll: boolean = false;
  
  currentPage: number = 1;
  pageSize: number = 10;
  totalPages: number = 1;
  totalItems: number = 0;
  startIndex: number = 1;
  endIndex: number = 6;

  

  ngOnInit(): void {
    this.loadSampleData();
    this.applyFilters();
  }

  loadSampleData(): void {
    this.transfers = [
      {
        id: '1',
        PolicyNo: '778-PT BANK MUAMALAT INDONESIA TBK Mortgage BMI Syariah',
        CertificateNo: '778000000058',
        InsuredId: 'CLJ0000113156',
         InsuredName: 'ACHMAD ZAHRONI',
       ProgressStatus: 'NB To be Issued',
        ReceivedDate: '12/10/2025 1:58:51 PM ',
        PendingItem: '',
        isFavorite: false,
        selected: false
      },
      {
        id: '2',
         PolicyNo: '778-PT BANK MUAMALAT INDONESIA TBK Mortgage BMI Syariah',
        CertificateNo: '778000000058',
        InsuredId: 'CLJ0000113156',
         InsuredName: 'ACHMAD ZAHRONI',
       ProgressStatus: 'NB To be Issued',
        ReceivedDate: '12/10/2025 1:58:51 PM ',
        PendingItem: '',
        isFavorite: false,
        selected: false
      },
      {
        id: '3',
         PolicyNo: '778-PT BANK MUAMALAT INDONESIA TBK Mortgage BMI Syariah',
        CertificateNo: '778000000058',
        InsuredId: 'CLJ0000113156',
         InsuredName: 'ACHMAD ZAHRONI',
       ProgressStatus: 'NB To be Issued',
        ReceivedDate: '12/10/2025 1:58:51 PM ',
        PendingItem: '',
        isFavorite: false,
        selected: false
      },
      {
        id: '4',
        PolicyNo: '778-PT BANK MUAMALAT INDONESIA TBK Mortgage BMI Syariah',
        CertificateNo: '778000000058',
        InsuredId: 'CLJ0000113156',
         InsuredName: 'ACHMAD ZAHRONI',
       ProgressStatus: 'NB To be Issued',
        ReceivedDate: '12/10/2025 1:58:51 PM ',
        PendingItem: '',
        isFavorite: false,
        selected: false
      },
      {
        id: '5',
        PolicyNo: '778-PT BANK MUAMALAT INDONESIA TBK Mortgage BMI Syariah',
        CertificateNo: '778000000058',
        InsuredId: 'CLJ0000113156',
         InsuredName: 'ACHMAD ZAHRONI',
       ProgressStatus: 'NB To be Issued',
        ReceivedDate: '12/10/2025 1:58:51 PM ',
        PendingItem: '',
        isFavorite: false,
        selected: false
      },
      {
        id: '6',
     PolicyNo: '778-PT BANK MUAMALAT INDONESIA TBK Mortgage BMI Syariah',
        CertificateNo: '778000000058',
        InsuredId: 'CLJ0000113156',
         InsuredName: 'ACHMAD ZAHRONI',
       ProgressStatus: 'NB To be Issued',
        ReceivedDate: '12/10/2025 1:58:51 PM ',
        PendingItem: '',
        isFavorite: false,
        selected: false
      }
    ];

    this.totalItems = this.transfers.length;
  }

  applyFilters(): void {
    let result = [...this.transfers];

    // Apply search filter
    if (this.searchQuery) {
      const query = this.searchQuery.toLowerCase();
      result = result.filter(transfer =>
        transfer.InsuredName.toLowerCase().includes(query) ||
        transfer.InsuredId.toLowerCase().includes(query) ||
        transfer.PolicyNo.toLowerCase().includes(query) ||
        transfer.ProgressStatus.toLowerCase().includes(query) ||
        transfer.PendingItem.toLowerCase().includes(query)
      );
    }

    // Apply favorites filter
    if (this.showFavoritesOnly) {
      result = result.filter(transfer => transfer.isFavorite);
    }

    this.filteredData = result;
    this.totalItems = result.length;
    this.calculatePagination();
    this.updatePaginatedData();
  }

  onSearch(): void {
    this.currentPage = 1;
    this.applyFilters();
  }

  toggleFilters(): void {
    this.showFilters = !this.showFilters;
  }

  toggleGroupBy(): void {
    this.isGrouped = !this.isGrouped;
  }

  toggleFavorites(): void {
    this.showFavoritesOnly = !this.showFavoritesOnly;
    this.currentPage = 1;
    this.applyFilters();
  }

  toggleFavorite(transfer: Transfer): void {
    transfer.isFavorite = !transfer.isFavorite;
  }

  onSelectAll(): void {
    this.paginatedData.forEach(transfer => {
      transfer.selected = this.selectAll;
    });
  }

  onSelectItem(): void {
    this.selectAll = this.paginatedData.every(transfer => transfer.selected);
  }

  calculatePagination(): void {
    this.totalPages = Math.ceil(this.totalItems / this.pageSize);
  }

  updatePaginatedData(): void {
    const start = (this.currentPage - 1) * this.pageSize;
    const end = start + this.pageSize;
    this.paginatedData = this.filteredData.slice(start, end);
    
    this.startIndex = this.totalItems > 0 ? start + 1 : 0;
    this.endIndex = Math.min(end, this.totalItems);
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
      this.updatePaginatedData();
    }
  }

  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.updatePaginatedData();
    }
  }

  toggleView(): void {
    console.log('Toggle view');
  }



  toggleSelect(): void {
    this.isSelectOpen = !this.isSelectOpen;
  }

  closeSelect(): void {
    this.isSelectOpen = false;
  }

  selectOption(option: string): void {
    this.selectedOption = option;
    this.isSelectOpen = false;
    
    if (option === 'New Certificate') {
      this.onNewCertificate();
    } else if (option === 'Complete') {
      this.onComplete();
    }
  }

  onNewCertificate(): void {
    console.log('Navigate to new certificate form');
    this.router.navigate(['/dashboard/certificate/new']);
  }

  onComplete(): void {
    console.log('Mark as complete');
    const selected = this.paginatedData.filter(item => item.selected);
    
    if (selected.length === 0) {
      alert('Please select at least one item to complete');
      return;
    }
    
    // Update status to complete
    selected.forEach(item => {
      item.PolicyNo = 'done';
    });
    
    console.log('Completed items:', selected);
    // Save to backend
    // this.certificateService.markAsComplete(selected).subscribe();
  }

}
