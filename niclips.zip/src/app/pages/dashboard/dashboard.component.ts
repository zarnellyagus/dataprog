import { Component, OnInit, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../../services/auth.service';

interface MenuItem {
  label: string;
  icon: string;
  route?: string;
  expanded?: boolean;
  children?: MenuItem[];
}

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  currentDate: string = '';
  selectedPeriod: string = 'Month';
  isSidebarOpen: boolean = true;
  isProfileMenuOpen: boolean = false;

  // User Profile Data
  userName: string = 'John Doe';
  userEmail: string = 'admin@demo.com';
  userRole: string = 'Administrator';
  userAvatar: string = '';
  userInitial: string = '';

  // Menu Items
  menu: MenuItem[] = [
    { label: 'Dashboard', icon: 'bi-speedometer2', route: '/dashboard' },

    { 
      label: 'Penjualan', 
      icon: 'bi-bag-check', 
      expanded: false,
      children: [
        { label: 'Penawaran Penjualan', icon: 'bi-file-earmark-text-fill', route: 'penjualan/datatable' },
        { label: 'Pesanan Penjualan', icon: 'bi-card-checklist', route: 'penjualan/transfer' },
        { label: 'Pengiriman Pesanan', icon: 'bi-truck', route: '/penjualan/pengiriman' },
        { label: 'Uang Muka Penjualan', icon: 'bi-wallet', route: '/penjualan/uang-muka' },
        { label: 'Penerimaan Penjualan', icon: 'bi-cash-coin', route: '/penjualan/penerimaan' },
        { label: 'Faktur Penjualan', icon: 'bi-card-heading', route: '/penjualan/faktur' },
        { label: 'Retur Penjualan', icon: 'bi-arrow-return-right', route: '/penjualan/retur' },
        { label: 'Kategori Pelanggan', icon: 'bi-tags', route: '/penjualan/kategori-pelanggan' },
        { label: 'Pelanggan', icon: 'bi-person-lines-fill', route: '/penjualan/pelanggan' }
      ]
    },

    {
      label: 'Pembelian',
      icon: 'bi-bag-plus',
      expanded: false,
      children: [
        { label: 'Pesanan Pembelian', icon: 'bi-file-earmark-text', route: '/pembelian/pesanan' },
        { label: 'Penerimaan Barang', icon: 'bi-box-arrow-in-down', route: '/pembelian/penerimaan' },
        { label: 'Faktur Pembelian', icon: 'bi-receipt', route: '/pembelian/faktur' },
        { label: 'Pembayaran', icon: 'bi-credit-card', route: '/pembelian/pembayaran' },
        { label: 'Retur', icon: 'bi-arrow-return-left', route: '/pembelian/retur' },
        { label: 'Harga Pemasok', icon: 'bi-tags', route: '/pembelian/harga-pemasok' },
        { label: 'Pemasok', icon: 'bi-people', route: '/pembelian/pemasok' },
        { label: 'Kategori Pemasok', icon: 'bi-folder', route: '/pembelian/kategori-pemasok' }
      ]
    },

    { 
      label: 'Persediaan',
      icon: 'bi-boxes', 
      expanded: false,
      children: [
        { label: 'Permintaan Barang', icon: 'bi-list-ul', route: '/persediaan/permintaan-barang' },
        { label: 'Permintaan Internal', icon: 'bi-list-check', route: '/persediaan/permintaan-internal' },
        { label: 'Internal Transfer', icon: 'bi-arrow-left-right', route: '/persediaan/transfer-barang' },
        { label: 'Penerimaan Bahan/Baku', icon: 'bi-arrow-down-square-fill', route: '/persediaan/penerimaan-barang' },
        { label: 'Manufaktur', icon: 'bi-gear-fill', route: '/persediaan/manufaktur' },
        { label: 'Penyesuaian Persediaan', icon: 'bi-box-seam-fill', route: '/persediaan/penyesuaian' },
        { label: 'Kartu Stock', icon: 'bi-card-text', route: '/persediaan/kartu-stok' },
        { label: 'Gudang', icon: 'bi-house-gear-fill', route: '/persediaan/gudang' },
        { label: 'Produk', icon: 'bi-box', route: '/persediaan/produk' },
        { label: 'Kategori Barang', icon: 'bi-folder', route: '/persediaan/kategori-barang' }, 
        { label: 'Satuan Barang', icon: 'bi-rulers', route: '/persediaan/satuan-barang' }
      ]
    },

    { label: 'Point Of Sale', icon: 'bi-cash-stack', route: '/pos' },

    {
      label: 'Akuntansi',
      icon: 'bi-calculator',
      expanded: false,
      children: [
        { label: 'Kode Akun', icon: 'bi-journal-richtext', route: '/akuntansi/kode-akun' },
        { label: 'Pajak', icon: 'bi-percent', route: '/akuntansi/pajak' },
        { label: 'Jurnal', icon: 'bi-journal-text', route: '/akuntansi/jurnal' }
      ]
    },

    {
      label: 'Karyawan',
      icon: 'bi-person-badge',
      expanded: false,
      children: [
        { label: 'Data Pegawai', icon: 'bi-people', route: '/karyawan/list-karyawan' },
        { label: 'Jadwal', icon: 'bi-calendar3', route: '/karyawan/jadwal' },
        { label: 'Gaji', icon: 'bi-wallet2', route: '/karyawan/gaji' }
      ]
    },

    {
      label: 'Pengaturan',
      icon: 'bi-gear-fill',
      expanded: false,
      children: [
        { label: 'Perusahaan', icon: 'bi-building-gear', route: '/pengaturan/perusahaan' },
        { label: 'Kategori Perusahaan', icon: 'bi-building', route: '/pengaturan/kategori-perusahaan' },
        { label: 'Pengguna', icon: 'bi-person-gear', route: '/pengaturan/pengguna' },
        { label: 'Backup', icon: 'bi-cloud-arrow-down', route: '/pengaturan/backup' }
      ]
    }
  ];

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.currentDate = new Date().toISOString().split('T')[0];
    this.checkScreenSize();
    this.generateUserInitial();
  }

  generateUserInitial(): void {
    if (this.userName) {
      const names = this.userName.split(' ');
      if (names.length >= 2) {
        this.userInitial = names[0][0] + names[1][0];
      } else {
        this.userInitial = names[0][0] + (names[0][1] || names[0][0]);
      }
      this.userInitial = this.userInitial.toUpperCase();
    }
  }

  // Toggle Submenu
  toggleSubmenu(item: MenuItem, event: Event): void {
    event.preventDefault();
    item.expanded = !item.expanded;
    
    // Close other submenus (optional - untuk accordion effect)
    // this.menu.forEach(menuItem => {
    //   if (menuItem !== item && menuItem.children) {
    //     menuItem.expanded = false;
    //   }
    // });
  }

  toggleProfileMenu(): void {
    this.isProfileMenuOpen = !this.isProfileMenuOpen;
  }

  closeProfileMenu(): void {
    this.isProfileMenuOpen = false;
  }

  onProfileClick(event: Event): void {
    event.preventDefault();
    this.closeProfileMenu();
    this.router.navigate(['/profile']);
  }

  onSettingsClick(event: Event): void {
    event.preventDefault();
    this.closeProfileMenu();
    this.router.navigate(['/settings']);
  }

  onHelpClick(event: Event): void {
    event.preventDefault();
    this.closeProfileMenu();
    this.router.navigate(['/help']);
  }

  toggleSidebar(): void {
    this.isSidebarOpen = !this.isSidebarOpen;
    localStorage.setItem('sidebarState', this.isSidebarOpen.toString());
    
    if (this.isSidebarOpen) {
      document.body.classList.remove('sidebar-collapsed');
    } else {
      document.body.classList.add('sidebar-collapsed');
    }
  }

  closeSidebarOnMobile(): void {
    if (window.innerWidth <= 768) {
      this.isSidebarOpen = false;
    }
  }

  @HostListener('window:resize', ['$event'])
  onResize(event: any): void {
    this.checkScreenSize();
  }

  private checkScreenSize(): void {
    if (window.innerWidth > 768) {
      const savedState = localStorage.getItem('sidebarState');
      this.isSidebarOpen = savedState ? savedState === 'true' : true;
    } else {
      this.isSidebarOpen = false;
    }
  }

  onLogout(event?: Event): void {
    if (event) {
      event.preventDefault();
    }
    this.closeProfileMenu();
    this.authService.logout();
  }

  selectPeriod(period: string): void {
    this.selectedPeriod = period;
  }
}
