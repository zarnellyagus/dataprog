import { Component, OnInit, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

interface Column {
  field: string;
  header: string;
  sortable?: boolean;
  type?: 'text' | 'number' | 'date' | 'currency';
}

@Component({
  selector: 'app-data-table',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './data-table.component.html',
  styleUrls: ['./data-table.component.css']
})
export class DataTableComponent implements OnInit {
  @Input() columns: Column[] = [];
  @Input() data: any[] = [];
  @Input() pageSize: number = 10;
  @Input() showPagination: boolean = true;

  currentPage: number = 1;
  totalPages: number = 1;
  totalItems: number = 0;
  paginatedData: any[] = [];
  sortColumn: string = '';
  sortDirection: 'asc' | 'desc' = 'asc';
  visiblePages: (number | string)[] = [];

  // Sample data untuk demo
  sampleData = [
    { orderId: '10248', customerId: 'VINET', employee: 'Buchanan', orderDate: '7/4/1996', requiredDate: '8/1/1996', shippedDate: '7/16/1996', freight: 32.3800 },
    { orderId: '10249', customerId: 'TOMSP', employee: 'Suyama', orderDate: '7/5/1996', requiredDate: '8/16/1996', shippedDate: '7/10/1996', freight: 11.6100 },
    { orderId: '10250', customerId: 'HANAR', employee: 'Peacock', orderDate: '7/8/1996', requiredDate: '8/5/1996', shippedDate: '7/12/1996', freight: 65.8300 },
    { orderId: '10251', customerId: 'VICTE', employee: 'Leverling', orderDate: '7/8/1996', requiredDate: '8/5/1996', shippedDate: '7/15/1996', freight: 41.3400 },
    { orderId: '10252', customerId: 'SUPRD', employee: 'Peacock', orderDate: '7/9/1996', requiredDate: '8/6/1996', shippedDate: '7/11/1996', freight: 51.3000 },
    { orderId: '10253', customerId: 'HANAR', employee: 'Leverling', orderDate: '7/10/1996', requiredDate: '7/24/1996', shippedDate: '7/16/1996', freight: 58.1700 },
    { orderId: '10254', customerId: 'CHOPS', employee: 'Buchanan', orderDate: '7/11/1996', requiredDate: '8/8/1996', shippedDate: '7/23/1996', freight: 22.9800 },
    { orderId: '10255', customerId: 'RICSU', employee: 'Dodsworth', orderDate: '7/12/1996', requiredDate: '8/9/1996', shippedDate: '7/15/1996', freight: 148.3300 }
  ];

  sampleColumns: Column[] = [
    { field: 'orderId', header: 'Order ID', sortable: true, type: 'text' },
    { field: 'customerId', header: 'Customer ID', sortable: true, type: 'text' },
    { field: 'employee', header: 'Employee', sortable: true, type: 'text' },
    { field: 'orderDate', header: 'Order Date', sortable: true, type: 'date' },
    { field: 'requiredDate', header: 'Required Date', sortable: true, type: 'date' },
    { field: 'shippedDate', header: 'Shipped Date', sortable: true, type: 'date' },
    { field: 'freight', header: 'Freight', sortable: true, type: 'number' }
  ];

  ngOnInit(): void {
    // Use sample data if no data provided
    if (this.data.length === 0) {
      // Generate more data for pagination demo
      this.data = this.generateSampleData(830);
    }
    
    if (this.columns.length === 0) {
      this.columns = this.sampleColumns;
    }

    this.totalItems = this.data.length;
    this.calculateTotalPages();
    this.updatePaginatedData();
    this.updateVisiblePages();
  }

  generateSampleData(count: number): any[] {
    const result = [];
    const customers = ['VINET', 'TOMSP', 'HANAR', 'VICTE', 'SUPRD', 'CHOPS', 'RICSU', 'WELLI'];
    const employees = ['Buchanan', 'Suyama', 'Peacock', 'Leverling', 'Dodsworth', 'King', 'Fuller'];
    
    for (let i = 0; i < count; i++) {
      const baseDate = new Date(1996, 6, 1);
      baseDate.setDate(baseDate.getDate() + i);
      
      result.push({
        orderId: String(10248 + i),
        customerId: customers[i % customers.length],
        employee: employees[i % employees.length],
        orderDate: this.formatDate(baseDate),
        requiredDate: this.formatDate(new Date(baseDate.getTime() + 25 * 24 * 60 * 60 * 1000)),
        shippedDate: this.formatDate(new Date(baseDate.getTime() + 10 * 24 * 60 * 60 * 1000)),
        freight: Math.random() * 200
      });
    }
    
    return result;
  }

  formatDate(date: Date): string {
    return `${date.getMonth() + 1}/${date.getDate()}/${date.getFullYear()}`;
  }

  calculateTotalPages(): void {
    this.totalPages = Math.ceil(this.totalItems / this.pageSize);
  }

  updatePaginatedData(): void {
    const startIndex = (this.currentPage - 1) * this.pageSize;
    const endIndex = startIndex + this.pageSize;
    this.paginatedData = this.data.slice(startIndex, endIndex);
  }

  updateVisiblePages(): void {
    const pages: (number | string)[] = [];
    const maxVisiblePages = 7;

    if (this.totalPages <= maxVisiblePages) {
      for (let i = 1; i <= this.totalPages; i++) {
        pages.push(i);
      }
    } else {
      if (this.currentPage <= 4) {
        for (let i = 1; i <= 5; i++) {
          pages.push(i);
        }
        pages.push('...');
        pages.push(this.totalPages);
      } else if (this.currentPage >= this.totalPages - 3) {
        pages.push(1);
        pages.push('...');
        for (let i = this.totalPages - 4; i <= this.totalPages; i++) {
          pages.push(i);
        }
      } else {
        pages.push(1);
        pages.push('...');
        for (let i = this.currentPage - 1; i <= this.currentPage + 1; i++) {
          pages.push(i);
        }
        pages.push('...');
        pages.push(this.totalPages);
      }
    }

    this.visiblePages = pages;
  }

  goToPage(page: number | string): void {
    if (typeof page === 'number' && page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
      this.updatePaginatedData();
      this.updateVisiblePages();
    }
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
      this.updatePaginatedData();
      this.updateVisiblePages();
    }
  }

  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.updatePaginatedData();
      this.updateVisiblePages();
    }
  }

  onSort(field: string): void {
    if (this.sortColumn === field) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumn = field;
      this.sortDirection = 'asc';
    }

    this.data.sort((a, b) => {
      const aValue = a[field];
      const bValue = b[field];

      let comparison = 0;
      if (aValue > bValue) {
        comparison = 1;
      } else if (aValue < bValue) {
        comparison = -1;
      }

      return this.sortDirection === 'asc' ? comparison : -comparison;
    });

    this.updatePaginatedData();
  }

  formatCellData(value: any, type?: string): string {
    if (value === null || value === undefined) {
      return '';
    }

    switch (type) {
      case 'number':
        return typeof value === 'number' ? value.toFixed(4) : value;
      case 'currency':
        return typeof value === 'number' ? value.toFixed(2) : value;
      case 'date':
        return value;
      default:
        return String(value);
    }
  }
}
