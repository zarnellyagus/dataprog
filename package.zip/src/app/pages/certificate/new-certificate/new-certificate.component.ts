import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, AbstractControl, ValidationErrors } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';

// ============================================
// INTERFACES
// ============================================

interface InsuredPerson {
  id: string;
  name: string;
  company: string;
  address: string;
  phone: string;
  email: string;
}

interface PolicyTypeOption {
  code: string;
  name: string;
  type: string;
  description: string;
  color: string;
  badgeColor: string;
}

interface PolicyType {
  value: string;
  label: string;
}

interface StatusOption {
  value: string;
  label: string;
}

interface CertificateFormData {
  // Step 1: Basic Information
  reference: string;
  certificateNumber: string;
  issuedDate: string;
  expiryDate: string;
  policyType: string;
  policyNumber: string;
  insuredName: string;
  insuredAddress: string;
  coverageAmount: number;
  premium: number;
  status: string;
  notes: string;
  
  // Step 2: Medical History
  hasMedicalHistory: boolean;
  diseaseType: string;
  height: number;
  weight: number;
  bloodPressure: string;
  bloodType: string;
  takingMedication: boolean;
  medicationDetails: string;
  additionalNotes: string;
}

// ============================================
// COMPONENT
// ============================================

@Component({
  selector: 'app-new-certificate',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './new-certificate.component.html',
  styleUrls: ['./new-certificate.component.css']
})
export class NewCertificateComponent implements OnInit, OnDestroy {
  
  // ============================================
  // PROPERTIES - Form State
  // ============================================
  
  certificateForm!: FormGroup;
  isEditMode: boolean = false;
  certificateId: string | null = null;
  isSubmitting: boolean = false;
  currentStep: number = 1;
  totalSteps: number = 3;

  // ============================================
  // PROPERTIES - Insured Modal State
  // ============================================
  
  isInsuredModalOpen: boolean = false;
  insuredSearchQuery: string = '';
  selectedInsured: InsuredPerson | null = null;

  // ============================================
  // PROPERTIES - Policy Modal State
  // ============================================
  
  isPolicyModalOpen: boolean = false;
  policySearchQuery: string = '';
  selectedPolicy: PolicyTypeOption | null = null;

  // ============================================
  // DATA - Insured List
  // ============================================
  
  insuredList: InsuredPerson[] = [
    {
      id: 'INS001',
      name: 'PT Teknologi Tinggi Indonesia',
      company: 'Technology Company',
      address: 'Jl. Sudirman No. 123, Jakarta Pusat, DKI Jakarta 10220',
      phone: '021-1234567',
      email: 'info@teknologi.com'
    },
    {
      id: 'INS002',
      name: 'PT Sejahtera Selalu Jaya',
      company: 'Trading Company',
      address: 'Jl. Gatot Subroto No. 45, Jakarta Selatan, DKI Jakarta 12930',
      phone: '021-7654321',
      email: 'contact@sejahtera.com'
    },
    {
      id: 'INS003',
      name: 'PT Neotek Maju Bersama',
      company: 'Manufacturing',
      address: 'Jl. HR Rasuna Said No. 67, Jakarta Selatan, DKI Jakarta 12940',
      phone: '021-9876543',
      email: 'info@neotek.com'
    },
    {
      id: 'INS004',
      name: 'PT Usaha Bagus Mandiri',
      company: 'Retail Business',
      address: 'Jl. Thamrin No. 89, Jakarta Pusat, DKI Jakarta 10350',
      phone: '021-5555666',
      email: 'contact@usahabagus.com'
    },
    {
      id: 'INS005',
      name: 'CV Mitra Sejahtera',
      company: 'Service Provider',
      address: 'Jl. Ahmad Yani No. 12, Jakarta Timur, DKI Jakarta 13220',
      phone: '021-3333444',
      email: 'info@mitrasejahtera.com'
    },
    {
      id: 'INS006',
      name: 'John Doe',
      company: 'Individual',
      address: 'Jl. Kebon Jeruk No. 34, Jakarta Barat, DKI Jakarta 11530',
      phone: '081234567890',
      email: 'john.doe@email.com'
    },
    {
      id: 'INS007',
      name: 'Jane Smith',
      company: 'Individual',
      address: 'Jl. Cempaka Putih No. 56, Jakarta Pusat, DKI Jakarta 10510',
      phone: '082345678901',
      email: 'jane.smith@email.com'
    },
    {
      id: 'INS008',
      name: 'PT Global Mandiri Solutions',
      company: 'IT Consulting',
      address: 'Jl. Kuningan No. 78, Jakarta Selatan, DKI Jakarta 12950',
      phone: '021-7777888',
      email: 'info@globalmandiri.com'
    },
    {
      id: 'INS009',
      name: 'Ahmad Rizki',
      company: 'Individual',
      address: 'Jl. Mangga Dua No. 90, Jakarta Utara, DKI Jakarta 14430',
      phone: '083456789012',
      email: 'ahmad.rizki@email.com'
    },
    {
      id: 'INS010',
      name: 'PT Persada Nusantara',
      company: 'Construction',
      address: 'Jl. Pluit No. 101, Jakarta Utara, DKI Jakarta 14440',
      phone: '021-8888999',
      email: 'info@persada.com'
    }
  ];

  filteredInsuredList: InsuredPerson[] = [];

  // ============================================
  // DATA - Policy Types List
  // ============================================
  
  policyTypesList: PolicyTypeOption[] = [
    {
      code: '778',
      name: 'Asuransi Syariah Konvensional',
      type: 'Syariah',
      description: 'Asuransi berbasis prinsip syariah dengan akad tabarru',
      color: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      badgeColor: '#667eea'
    },
    {
      code: 'BMI Syariah',
      name: 'Bank Muamalat Indonesia Syariah',
      type: 'Perbankan Syariah',
      description: 'Produk asuransi dari Bank Muamalat Indonesia',
      color: 'linear-gradient(135deg, #11998e 0%, #38ef7d 100%)',
      badgeColor: '#11998e'
    },
    {
      code: '7862 CIMB SYARIAH',
      name: 'CIMB Niaga Syariah',
      type: 'Perbankan Syariah',
      description: 'Produk asuransi syariah dari CIMB Niaga',
      color: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
      badgeColor: '#f5576c'
    },
    {
      code: '1001',
      name: 'Prudential Syariah',
      type: 'Asuransi Jiwa',
      description: 'Asuransi jiwa berbasis syariah',
      color: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
      badgeColor: '#4facfe'
    },
    {
      code: '2002',
      name: 'Allianz Syariah',
      type: 'Asuransi Umum',
      description: 'Asuransi umum dengan prinsip syariah',
      color: 'linear-gradient(135deg, #fa709a 0%, #fee140 100%)',
      badgeColor: '#fa709a'
    },
    {
      code: '3003',
      name: 'Takaful Indonesia',
      type: 'Takaful',
      description: 'Asuransi takaful murni berbasis syariah',
      color: 'linear-gradient(135deg, #30cfd0 0%, #330867 100%)',
      badgeColor: '#30cfd0'
    },
    {
      code: '4004',
      name: 'AIA Syariah',
      type: 'Asuransi Jiwa',
      description: 'Asuransi jiwa internasional syariah',
      color: 'linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)',
      badgeColor: '#a8edea'
    },
    {
      code: '5005',
      name: 'Mandiri Syariah',
      type: 'Perbankan Syariah',
      description: 'Produk asuransi dari Bank Mandiri Syariah',
      color: 'linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%)',
      badgeColor: '#ff9a9e'
    },
    {
      code: '6006',
      name: 'BRI Syariah',
      type: 'Perbankan Syariah',
      description: 'Produk asuransi dari Bank BRI Syariah',
      color: 'linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%)',
      badgeColor: '#fcb69f'
    },
    {
      code: '7007',
      name: 'BNI Syariah',
      type: 'Perbankan Syariah',
      description: 'Produk asuransi dari Bank BNI Syariah',
      color: 'linear-gradient(135deg, #ff6e7f 0%, #bfe9ff 100%)',
      badgeColor: '#ff6e7f'
    }
  ];

  filteredPolicyList: PolicyTypeOption[] = [];

  // ============================================
  // DATA - Legacy Policy Types (for backward compatibility)
  // ============================================
  
  policyTypes: PolicyType[] = [
    { value: 'life', label: 'Life Insurance' },
    { value: 'health', label: 'Health Insurance' },
    { value: 'vehicle', label: 'Vehicle Insurance' },
    { value: 'property', label: 'Property Insurance' },
    { value: 'travel', label: 'Travel Insurance' }
  ];

  // ============================================
  // DATA - Status Options
  // ============================================
  
  statusOptions: StatusOption[] = [
    { value: 'draft', label: 'Draft' },
    { value: 'active', label: 'Active' },
    { value: 'pending', label: 'Pending Review' },
    { value: 'expired', label: 'Expired' }
  ];

  // ============================================
  // SUBSCRIPTIONS
  // ============================================
  
  private subscriptions: Subscription = new Subscription();

  // ============================================
  // CONSTRUCTOR
  // ============================================
  
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  // ============================================
  // LIFECYCLE HOOKS
  // ============================================

  ngOnInit(): void {
    this.initializeComponent();
  }

  ngOnDestroy(): void {
    this.cleanupComponent();
  }

  private initializeComponent(): void {
    this.initializeForm();
    this.checkEditMode();
    this.initializeFilteredLists();
    this.setupFormValueChanges();
  }

  private cleanupComponent(): void {
    this.subscriptions.unsubscribe();
    document.body.style.overflow = 'auto';
  }

  private initializeFilteredLists(): void {
    this.filteredInsuredList = [...this.insuredList];
    this.filteredPolicyList = [...this.policyTypesList];
  }

  // ============================================
  // FORM INITIALIZATION
  // ============================================

  private initializeForm(): void {
    this.certificateForm = this.fb.group({
      // Step 1: Basic Information
      reference: ['', Validators.required],
      certificateNumber: [
        '', 
        [
          Validators.required, 
          Validators.pattern(/^CERT-\d{6}$/)
        ]
      ],
      issuedDate: ['', [Validators.required, this.dateValidator.bind(this)]],
      expiryDate: ['', [Validators.required, this.futureDateValidator.bind(this)]],
      policyType: ['', Validators.required],
      policyNumber: ['', [Validators.required, Validators.minLength(5)]],
      insuredName: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(100)]],
      insuredAddress: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(500)]],
      coverageAmount: [
        0, 
        [
          Validators.required, 
          Validators.min(1000000), 
          Validators.max(10000000000)
        ]
      ],
      premium: [
        0, 
        [
          Validators.required, 
          Validators.min(100000), 
          Validators.max(100000000)
        ]
      ],
      status: ['draft', Validators.required],
      notes: ['', Validators.maxLength(500)],
      
      // Step 2: Medical History
      hasMedicalHistory: [false, Validators.required],
      diseaseType: [''],
      height: ['', [Validators.required, Validators.min(100), Validators.max(250)]],
      weight: ['', [Validators.required, Validators.min(30), Validators.max(300)]],
      bloodPressure: ['', [Validators.required, Validators.pattern(/^\d{2,3}\/\d{2,3}$/)]],
      bloodType: ['', Validators.required],
      takingMedication: [false, Validators.required],
      medicationDetails: [''],
      additionalNotes: ['', Validators.maxLength(1000)]
    });

    this.generateReference();
  }

  private setupFormValueChanges(): void {
    // Watch hasMedicalHistory changes
    const hasMedicalHistorySub = this.certificateForm
      .get('hasMedicalHistory')
      ?.valueChanges.subscribe((value: boolean) => {
        this.updateDiseaseTypeValidation(value);
      });

    // Watch takingMedication changes
    const takingMedicationSub = this.certificateForm
      .get('takingMedication')
      ?.valueChanges.subscribe((value: boolean) => {
        this.updateMedicationDetailsValidation(value);
      });

    // Watch issuedDate changes for expiry date validation
    const issuedDateSub = this.certificateForm
      .get('issuedDate')
      ?.valueChanges.subscribe(() => {
        this.certificateForm.get('expiryDate')?.updateValueAndValidity();
      });

    // Add subscriptions
    if (hasMedicalHistorySub) this.subscriptions.add(hasMedicalHistorySub);
    if (takingMedicationSub) this.subscriptions.add(takingMedicationSub);
    if (issuedDateSub) this.subscriptions.add(issuedDateSub);
  }

  private updateDiseaseTypeValidation(hasMedicalHistory: boolean): void {
    const diseaseTypeControl = this.certificateForm.get('diseaseType');
    if (hasMedicalHistory) {
      diseaseTypeControl?.setValidators([
        Validators.required, 
        Validators.minLength(5),
        Validators.maxLength(500)
      ]);
    } else {
      diseaseTypeControl?.clearValidators();
      diseaseTypeControl?.setValue('');
    }
    diseaseTypeControl?.updateValueAndValidity();
  }

  private updateMedicationDetailsValidation(takingMedication: boolean): void {
    const medicationDetailsControl = this.certificateForm.get('medicationDetails');
    if (takingMedication) {
      medicationDetailsControl?.setValidators([
        Validators.required, 
        Validators.minLength(5),
        Validators.maxLength(500)
      ]);
    } else {
      medicationDetailsControl?.clearValidators();
      medicationDetailsControl?.setValue('');
    }
    medicationDetailsControl?.updateValueAndValidity();
  }

  // ============================================
  // CUSTOM VALIDATORS
  // ============================================

  private dateValidator(control: AbstractControl): ValidationErrors | null {
    if (!control.value) {
      return null;
    }

    const inputDate = new Date(control.value);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // For issued date, allow today or future dates
    if (inputDate < today) {
      return { pastDate: true };
    }

    return null;
  }

  private futureDateValidator(control: AbstractControl): ValidationErrors | null {
    if (!control.value) {
      return null;
    }

    const expiryDate = new Date(control.value);
    const issuedDateValue = this.certificateForm?.get('issuedDate')?.value;
    
    if (issuedDateValue) {
      const issuedDate = new Date(issuedDateValue);
      
      // Expiry date must be after issued date
      if (expiryDate <= issuedDate) {
        return { expiryBeforeIssued: true };
      }

      // Expiry date should be at least 1 year from issued date
      const oneYearLater = new Date(issuedDate);
      oneYearLater.setFullYear(oneYearLater.getFullYear() + 1);
      
      if (expiryDate < oneYearLater) {
        return { expiryTooSoon: true };
      }
    }

    return null;
  }

  // ============================================
  // FORM GENERATION
  // ============================================

  private generateReference(): void {
    const timestamp = Date.now();
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    const certNumber = timestamp.toString().slice(-6);
    
    this.certificateForm.patchValue({
      reference: `REF-${timestamp}-${random}`,
      certificateNumber: `CERT-${certNumber}`,
      issuedDate: this.formatDate(new Date())
    });
  }

  private formatDate(date: Date): string {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  // ============================================
  // EDIT MODE
  // ============================================

  private checkEditMode(): void {
    this.certificateId = this.route.snapshot.paramMap.get('id');
    if (this.certificateId) {
      this.isEditMode = true;
      this.loadCertificateData(this.certificateId);
    }
  }

  private loadCertificateData(id: string): void {
    console.log('Loading certificate:', id);
    
    // Simulate API call with mock data
    const mockData: Partial<CertificateFormData> = {
      reference: 'REF-1234567890-123',
      certificateNumber: 'CERT-567890',
      issuedDate: '2026-01-18',
      expiryDate: '2027-01-18',
      policyType: '778 - Asuransi Syariah Konvensional',
      policyNumber: 'POL-123456',
      insuredName: 'PT Teknologi Tinggi Indonesia',
      insuredAddress: 'Jl. Sudirman No. 123, Jakarta Pusat, DKI Jakarta 10220',
      coverageAmount: 50000000,
      premium: 5000000,
      status: 'active',
      notes: 'Test certificate data',
      hasMedicalHistory: true,
      diseaseType: 'Diabetes Type 2',
      height: 170,
      weight: 70,
      bloodPressure: '120/80',
      bloodType: 'A',
      takingMedication: true,
      medicationDetails: 'Metformin 500mg twice daily',
      additionalNotes: 'Regular checkup required every 3 months'
    };

    // Simulate network delay
    setTimeout(() => {
      this.certificateForm.patchValue(mockData);
      console.log('Certificate data loaded successfully');
    }, 500);

    // Real API implementation:
    // this.certificateService.getCertificate(id).subscribe({
    //   next: (data) => {
    //     this.certificateForm.patchValue(data);
    //   },
    //   error: (error) => {
    //     console.error('Error loading certificate:', error);
    //     alert('Failed to load certificate data');
    //     this.router.navigate(['/dashboard/transfers']);
    //   }
    // });
  }

  // ============================================
  // STEP NAVIGATION
  // ============================================

  nextStep(): void {
    if (!this.validateCurrentStep()) {
      return;
    }

    if (this.currentStep < this.totalSteps) {
      this.currentStep++;
      this.scrollToTop();
      console.log(`Moved to step ${this.currentStep}`);
    }
  }

  previousStep(): void {
    if (this.currentStep > 1) {
      this.currentStep--;
      this.scrollToTop();
      console.log(`Moved back to step ${this.currentStep}`);
    }
  }

  private scrollToTop(): void {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  getNextStepLabel(): string {
    const labels: { [key: number]: string } = {
      1: 'Riwayat Kesehatan',
      2: 'Review'
    };
    return labels[this.currentStep] || 'Next';
  }

  // ============================================
  // VALIDATION
  // ============================================

  private validateCurrentStep(): boolean {
    const fieldsToValidate = this.getFieldsForStep(this.currentStep);
    let isValid = true;

    // Validate required fields
    fieldsToValidate.forEach(field => {
      const control = this.certificateForm.get(field);
      if (control && control.invalid) {
        control.markAsTouched();
        isValid = false;
      }
    });

    // Additional cross-field validations
    if (this.currentStep === 1) {
      isValid = this.validateStep1() && isValid;
    } else if (this.currentStep === 2) {
      isValid = this.validateStep2() && isValid;
    }

    if (!isValid) {
      const stepName = this.getStepName(this.currentStep);
      alert(`Please fill in all required ${stepName} fields correctly before proceeding.`);
      return false;
    }

    return true;
  }

  private getFieldsForStep(step: number): string[] {
    const fieldsByStep: { [key: number]: string[] } = {
      1: [
        'reference', 
        'certificateNumber', 
        'issuedDate', 
        'expiryDate',
        'policyType', 
        'policyNumber', 
        'insuredName', 
        'insuredAddress',
        'coverageAmount', 
        'premium', 
        'status'
      ],
      2: [
        'hasMedicalHistory',
        'height', 
        'weight', 
        'bloodPressure', 
        'bloodType',
        'takingMedication'
      ]
    };

    return fieldsByStep[step] || [];
  }

  private validateStep1(): boolean {
    const issuedDate = new Date(this.certificateForm.get('issuedDate')?.value);
    const expiryDate = new Date(this.certificateForm.get('expiryDate')?.value);
    
    if (expiryDate <= issuedDate) {
      alert('Expiry date must be after issued date.');
      return false;
    }

    const coverageAmount = this.certificateForm.get('coverageAmount')?.value;
    const premium = this.certificateForm.get('premium')?.value;

    if (premium >= coverageAmount) {
      alert('Premium amount should be less than coverage amount.');
      return false;
    }

    return true;
  }

  private validateStep2(): boolean {
    let isValid = true;

    // Validate conditional fields
    if (this.certificateForm.get('hasMedicalHistory')?.value === true) {
      const diseaseType = this.certificateForm.get('diseaseType');
      if (!diseaseType?.value || diseaseType.invalid) {
        diseaseType?.markAsTouched();
        isValid = false;
      }
    }

    if (this.certificateForm.get('takingMedication')?.value === true) {
      const medicationDetails = this.certificateForm.get('medicationDetails');
      if (!medicationDetails?.value || medicationDetails.invalid) {
        medicationDetails?.markAsTouched();
        isValid = false;
      }
    }

    // Validate BMI
    const bmi = this.calculateBMI();
    if (bmi > 0 && (bmi < 15 || bmi > 50)) {
      alert('Height and weight values seem unusual. Please verify the measurements.');
      return false;
    }

    return isValid;
  }

  private getStepName(step: number): string {
    const stepNames: { [key: number]: string } = {
      1: 'basic information',
      2: 'medical history',
      3: 'review'
    };
    return stepNames[step] || 'form';
  }

  isFieldInvalid(fieldName: string): boolean {
    const field = this.certificateForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  getErrorMessage(fieldName: string): string {
    const field = this.certificateForm.get(fieldName);
    
    if (!field) {
      return '';
    }

    if (field.hasError('required')) {
      return 'This field is required';
    }
    
    if (field.hasError('minlength')) {
      const requiredLength = field.errors?.['minlength'].requiredLength;
      return `Minimum length is ${requiredLength} characters`;
    }
    
    if (field.hasError('maxlength')) {
      const requiredLength = field.errors?.['maxlength'].requiredLength;
      return `Maximum length is ${requiredLength} characters`;
    }
    
    if (field.hasError('pattern')) {
      return this.getPatternErrorMessage(fieldName);
    }
    
    if (field.hasError('min')) {
      const minValue = field.errors?.['min'].min;
      return `Value must be at least ${this.formatNumber(minValue)}`;
    }
    
    if (field.hasError('max')) {
      const maxValue = field.errors?.['max'].max;
      return `Value must not exceed ${this.formatNumber(maxValue)}`;
    }

    if (field.hasError('pastDate')) {
      return 'Date cannot be in the past';
    }

    if (field.hasError('expiryBeforeIssued')) {
      return 'Expiry date must be after issued date';
    }

    if (field.hasError('expiryTooSoon')) {
      return 'Expiry date should be at least 1 year from issued date';
    }

    return '';
  }

  private getPatternErrorMessage(fieldName: string): string {
    const patterns: { [key: string]: string } = {
      'certificateNumber': 'Invalid format (e.g., CERT-123456)',
      'bloodPressure': 'Invalid format (e.g., 120/80)',
      'policyNumber': 'Invalid policy number format'
    };
    return patterns[fieldName] || 'Invalid format';
  }

  private markFormGroupTouched(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach(key => {
      const control = formGroup.get(key);
      control?.markAsTouched();

      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }

  // ============================================
  // INSURED MODAL METHODS
  // ============================================

  openInsuredModal(): void {
    this.isInsuredModalOpen = true;
    this.insuredSearchQuery = '';
    this.filteredInsuredList = [...this.insuredList];
    this.selectedInsured = null;
    document.body.style.overflow = 'hidden';
    console.log('Insured modal opened');
  }

  closeInsuredModal(): void {
    this.isInsuredModalOpen = false;
    this.insuredSearchQuery = '';
    this.selectedInsured = null;
    document.body.style.overflow = 'auto';
    console.log('Insured modal closed');
  }

  filterInsuredList(): void {
    const query = this.insuredSearchQuery.toLowerCase().trim();
    
    if (!query) {
      this.filteredInsuredList = [...this.insuredList];
      return;
    }

    this.filteredInsuredList = this.insuredList.filter(insured =>
      insured.name.toLowerCase().includes(query) ||
      insured.id.toLowerCase().includes(query) ||
      insured.company.toLowerCase().includes(query) ||
      insured.address.toLowerCase().includes(query) ||
      insured.email.toLowerCase().includes(query) ||
      insured.phone.includes(query)
    );

    console.log(`Filtered insured list: ${this.filteredInsuredList.length} results`);
  }

  selectInsured(insured: InsuredPerson): void {
    this.selectedInsured = insured;
    console.log('Selected insured:', insured);
  }

  confirmInsuredSelection(): void {
    if (this.selectedInsured) {
      this.certificateForm.patchValue({
        insuredName: this.selectedInsured.name,
        insuredAddress: this.selectedInsured.address
      });
      
      console.log('Insured person selected and form updated:', this.selectedInsured);
      this.closeInsuredModal();
    }
  }

  // ============================================
  // POLICY MODAL METHODS
  // ============================================

  openPolicyModal(): void {
    this.isPolicyModalOpen = true;
    this.policySearchQuery = '';
    this.filteredPolicyList = [...this.policyTypesList];
    this.selectedPolicy = null;
    document.body.style.overflow = 'hidden';
    console.log('Policy modal opened');
  }

  closePolicyModal(): void {
    this.isPolicyModalOpen = false;
    this.policySearchQuery = '';
    this.selectedPolicy = null;
    document.body.style.overflow = 'auto';
    console.log('Policy modal closed');
  }

  filterPolicyList(): void {
    const query = this.policySearchQuery.toLowerCase().trim();
    
    if (!query) {
      this.filteredPolicyList = [...this.policyTypesList];
      return;
    }

    this.filteredPolicyList = this.policyTypesList.filter(policy =>
      policy.code.toLowerCase().includes(query) ||
      policy.name.toLowerCase().includes(query) ||
      policy.type.toLowerCase().includes(query) ||
      policy.description.toLowerCase().includes(query)
    );

    console.log(`Filtered policy list: ${this.filteredPolicyList.length} results`);
  }

  selectPolicy(policy: PolicyTypeOption): void {
    this.selectedPolicy = policy;
    console.log('Selected policy:', policy);
  }

  confirmPolicySelection(): void {
    if (this.selectedPolicy) {
      const policyValue = `${this.selectedPolicy.code} - ${this.selectedPolicy.name}`;
      this.certificateForm.patchValue({
        policyType: policyValue
      });
      
      console.log('Policy type selected and form updated:', this.selectedPolicy);
      this.closePolicyModal();
    }
  }

  // ============================================
  // FORM SUBMISSION
  // ============================================

  onSubmit(): void {
    console.log('Form submission started');

    if (this.certificateForm.invalid) {
      this.markFormGroupTouched(this.certificateForm);
      alert('Please fill in all required fields correctly');
      console.error('Form validation failed:', this.getFormErrors());
      return;
    }

    this.isSubmitting = true;
    const formData = this.certificateForm.value as CertificateFormData;

    console.log('Form Data to Submit:', formData);

    if (this.isEditMode) {
      this.updateCertificate(formData);
    } else {
      this.createCertificate(formData);
    }
  }

  private createCertificate(data: CertificateFormData): void {
    console.log('Creating new certificate...', data);
    
    // Simulate API call
    setTimeout(() => {
      this.isSubmitting = false;
      console.log('Certificate created successfully');
      alert('Certificate created successfully!');
      this.router.navigate(['/dashboard/transfers']);
    }, 1500);

    // Real API implementation:
    // this.certificateService.create(data).subscribe({
    //   next: (response) => {
    //     this.isSubmitting = false;
    //     console.log('Certificate created:', response);
    //     alert('Certificate created successfully!');
    //     this.router.navigate(['/dashboard/transfers']);
    //   },
    //   error: (error) => {
    //     this.isSubmitting = false;
    //     console.error('Error creating certificate:', error);
    //     alert('Error creating certificate: ' + (error.message || 'Unknown error'));
    //   }
    // });
  }

  private updateCertificate(data: CertificateFormData): void {
    console.log('Updating certificate:', this.certificateId, data);
    
    setTimeout(() => {
      this.isSubmitting = false;
      console.log('Certificate updated successfully');
      alert('Certificate updated successfully!');
      this.router.navigate(['/dashboard/transfers']);
    }, 1500);

    // Real API implementation:
    // this.certificateService.update(this.certificateId!, data).subscribe({
    //   next: (response) => {
    //     this.isSubmitting = false;
    //     console.log('Certificate updated:', response);
    //     alert('Certificate updated successfully!');
    //     this.router.navigate(['/dashboard/transfers']);
    //   },
    //   error: (error) => {
    //     this.isSubmitting = false;
    //     console.error('Error updating certificate:', error);
    //     alert('Error updating certificate: ' + (error.message || 'Unknown error'));
    //   }
    // });
  }

  onSaveDraft(): void {
    console.log('Saving as draft...');
    this.certificateForm.patchValue({ status: 'draft' });
    
    // Skip validation for draft save
    this.isSubmitting = true;
    const formData = this.certificateForm.value as CertificateFormData;

    console.log('Draft data:', formData);

    setTimeout(() => {
      this.isSubmitting = false;
      console.log('Draft saved successfully');
      alert('Draft saved successfully!');
    }, 1000);

    // Real API implementation:
    // this.certificateService.saveDraft(formData).subscribe({
    //   next: (response) => {
    //     this.isSubmitting = false;
    //     console.log('Draft saved:', response);
    //     alert('Draft saved successfully!');
    //   },
    //   error: (error) => {
    //     this.isSubmitting = false;
    //     console.error('Error saving draft:', error);
    //     alert('Error saving draft: ' + (error.message || 'Unknown error'));
    //   }
    // });
  }

  onCancel(): void {
    const hasChanges = this.certificateForm.dirty;
    
    if (hasChanges) {
      const confirmed = confirm('Are you sure you want to cancel? All unsaved changes will be lost.');
      if (confirmed) {
        console.log('Form cancelled by user');
        this.router.navigate(['/dashboard/transfers']);
      }
    } else {
      console.log('Form cancelled (no changes)');
      this.router.navigate(['/dashboard/transfers']);
    }
  }

  // ============================================
  // UTILITY METHODS
  // ============================================

  calculateBMI(): number {
    const height = this.certificateForm.get('height')?.value;
    const weight = this.certificateForm.get('weight')?.value;
    
    if (height && weight && height > 0) {
      const heightInMeters = height / 100;
      const bmi = weight / (heightInMeters * heightInMeters);
      return Math.round(bmi * 10) / 10;
    }
    
    return 0;
  }

  getBMICategory(): string {
    const bmi = this.calculateBMI();
    
    if (bmi === 0) return '';
    if (bmi < 18.5) return 'Underweight';
    if (bmi < 25) return 'Normal';
    if (bmi < 30) return 'Overweight';
    return 'Obese';
  }

  formatCurrency(value: number): string {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value);
  }

  formatNumber(value: number): string {
    return new Intl.NumberFormat('id-ID').format(value);
  }

  getPolicyCode(): string {
    const policyType = this.certificateForm.get('policyType')?.value;
    if (policyType && typeof policyType === 'string') {
      const parts = policyType.split(' - ');
      return parts[0] || '';
    }
    return '';
  }

  getPolicyName(): string {
    const policyType = this.certificateForm.get('policyType')?.value;
    if (policyType && typeof policyType === 'string') {
      const parts = policyType.split(' - ');
      return parts[1] || '';
    }
    return '';
  }

  // ============================================
  // DEBUGGING METHODS (Development only)
  // ============================================

  logFormValue(): void {
    console.log('=== FORM DEBUG INFO ===');
    console.log('Form Value:', this.certificateForm.value);
    console.log('Form Valid:', this.certificateForm.valid);
    console.log('Form Dirty:', this.certificateForm.dirty);
    console.log('Form Touched:', this.certificateForm.touched);
    console.log('Form Errors:', this.getFormErrors());
    console.log('Current Step:', this.currentStep);
    console.log('Edit Mode:', this.isEditMode);
    console.log('======================');
  }

  private getFormErrors(): any {
    const errors: any = {};
    Object.keys(this.certificateForm.controls).forEach(key => {
      const control = this.certificateForm.get(key);
      if (control && control.errors) {
        errors[key] = control.errors;
      }
    });
    return errors;
  }

  // For development: expose form for console debugging
  getForm(): FormGroup {
    return this.certificateForm;
  }
}
