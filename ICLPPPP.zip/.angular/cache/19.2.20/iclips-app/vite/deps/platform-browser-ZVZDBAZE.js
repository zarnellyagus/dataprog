// optional-peer-dep:__vite-optional-peer-dep:@angular/animations/browser:@angular/platform-browser
throw new Error(`Could not resolve "@angular/animations/browser" imported by "@angular/platform-browser". Is it installed?`);
//# sourceMappingURL=platform-browser-ZVZDBAZE.js.map
