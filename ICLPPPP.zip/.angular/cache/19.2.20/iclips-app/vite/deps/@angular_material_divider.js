import {
  MatDivider,
  MatDividerModule
} from "./chunk-4NOSQYPG.js";
import "./chunk-PCQEEKRW.js";
import "./chunk-RSCAAIHO.js";
import "./chunk-OLWUMG6R.js";
import "./chunk-MVNJMFVL.js";
import "./chunk-GIYX2BAP.js";
import "./chunk-U7YDHSFO.js";
import "./chunk-UGCR7KEQ.js";
import "./chunk-S35MAB2V.js";
export {
  MatDivider,
  MatDividerModule
};
