import { Injectable, inject, signal } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, BehaviorSubject, tap, catchError, throwError, of, delay } from 'rxjs';

export interface User {
  id: string;
  email: string;
  name: string;
  role: string;
}

export interface AuthResponse {
  token: string;
  user: User;
  expiresIn?: number;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private http = inject(HttpClient);
  private router = inject(Router);

  private readonly AZURE_SSO_CONFIG = {
    EntityId: 'https://istaruat.id.sunlife:4490/',
    AcsUrl: 'https://istaruat.id.sunlife:4491/api/auth-service/sso-callback',
    LoginUrl: 'https://login.microsoftonline.com/415bb08f-1a20-4fbe-9b57-313be7050945/saml2',
    MetadataUrl: 'https://login.microsoftonline.com/415bb08f-1a20-4fbe-9b57-313be7050945/federationmetadata/2007-06/federationmetadata.xml',
    Issuer: 'https://sts.windows.net/415bb03f-1a20-4fbe-9b57-313be7050945/',
    LogoutUrl: 'https://login.microsoftonline.com/415bb08f-1a20-4fbe-9b57-313be7050945/saml2'
  };

  // Mock credentials
  private readonly MOCK_CREDENTIALS = {
    username: 'admin',
    password: 'admin'
  };

  private currentUserSubject = new BehaviorSubject<User | null>(null);
  public currentUser$ = this.currentUserSubject.asObservable();
  
  isAuthenticatedSignal = signal(false);

  constructor() {
    this.checkAuthStatus();
  }

  /**
   * Login - Check mock credentials first, then try real API
   */
  login(username: string, password: string): Observable<AuthResponse> {
    // Check if credentials match mock admin
    if (username === this.MOCK_CREDENTIALS.username && 
        password === this.MOCK_CREDENTIALS.password) {
      return this.mockLogin(username);
    }

    // Try real API login
    return this.http.post<AuthResponse>('/api/auth/login', { username, password })
      .pipe(
        tap(response => this.handleAuthSuccess(response)),
        catchError(error => {
          console.error('Real API login failed, trying mock login:', error);
          // If API fails, try mock login as fallback
          return this.mockLogin(username);
        })
      );
  }

  /**
   * Mock Login - For development without JWT
   */
  private mockLogin(username: string): Observable<AuthResponse> {
    const mockUser: User = {
      id: 'mock-001',
      email: `${username}@sunlife.com`,
      name: username === 'admin' ? 'Administrator' : username,
      role: 'admin'
    };

    const mockToken = 'mock-token-' + Date.now();

    const mockResponse: AuthResponse = {
      token: mockToken,
      user: mockUser,
      expiresIn: 86400 // 24 hours
    };

    console.log('Using mock login for:', username);

    return of(mockResponse).pipe(
      delay(500), // Simulate network delay
      tap(response => this.handleAuthSuccess(response))
    );
  }

  /**
   * Azure SAML SSO Login
   */
  loginWithAzureSSO(): void {
    localStorage.setItem('redirectUrl', this.router.url);
    localStorage.setItem('loginMethod', 'sso');
    
    // Try to redirect to Azure SSO
    try {
      window.location.href = this.AZURE_SSO_CONFIG.LoginUrl;
    } catch (error) {
      console.error('Failed to redirect to Azure SSO:', error);
      // If SSO redirect fails, redirect back to login with error
      this.router.navigate(['/login'], {
        queryParams: { error: 'sso_redirect_failed' }
      });
    }
  }

  /**
   * Handle SSO callback
   */
  handleSSOCallback(samlResponse: string): Observable<AuthResponse> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });

    return this.http.post<AuthResponse>(
      this.AZURE_SSO_CONFIG.AcsUrl,
      { SAMLResponse: samlResponse },
      { headers }
    ).pipe(
      tap(response => this.handleAuthSuccess(response)),
      catchError(error => {
        console.error('SSO callback failed:', error);
        // If SSO fails, use mock login
        return this.mockLogin('sso-user');
      })
    );
  }

  /**
   * Set authenticated state
   */
  setAuthenticated(token: string, user: User): void {
    localStorage.setItem('authToken', token);
    localStorage.setItem('user', JSON.stringify(user));
    
    this.currentUserSubject.next(user);
    this.isAuthenticatedSignal.set(true);

    const redirectUrl = localStorage.getItem('redirectUrl') || '/dashboard';
    localStorage.removeItem('redirectUrl');
    this.router.navigate([redirectUrl]);
  }

  /**
   * Check authentication status
   */
  checkAuthStatus(): void {
    const token = this.getToken();
    const userJson = localStorage.getItem('user');

    if (token && userJson) {
      try {
        const user = JSON.parse(userJson) as User;
        this.currentUserSubject.next(user);
        this.isAuthenticatedSignal.set(true);
      } catch (error) {
        console.error('Error parsing user data:', error);
        this.logout();
      }
    }
  }

  /**
   * Check if authenticated - Support mock tokens
   */
  isAuthenticated(): boolean {
    const token = this.getToken();
    if (!token) {
      return false;
    }

    // If it's a mock token, just check if it exists
    if (token.startsWith('mock-token-')) {
      return true;
    }

    // For real JWT tokens, check expiry
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      const expiry = payload.exp * 1000;
      
      if (Date.now() >= expiry) {
        this.logout();
        return false;
      }
      return true;
    } catch {
      // If token parsing fails, still allow access (for mock tokens)
      return !!token;
    }
  }

  /**
   * Get current user
   */
  getCurrentUser(): User | null {
    return this.currentUserSubject.value;
  }

  /**
   * Get token
   */
  getToken(): string | null {
    return localStorage.getItem('authToken');
  }

  /**
   * Logout
   */
  logout(): void {
    const isSSO = localStorage.getItem('loginMethod') === 'sso';
    
    localStorage.removeItem('authToken');
    localStorage.removeItem('user');
    localStorage.removeItem('redirectUrl');
    localStorage.removeItem('loginMethod');

    this.currentUserSubject.next(null);
    this.isAuthenticatedSignal.set(false);

    if (isSSO) {
      try {
        window.location.href = this.AZURE_SSO_CONFIG.LogoutUrl;
      } catch (error) {
        console.error('Failed to redirect to Azure logout:', error);
        this.router.navigate(['/login']);
      }
    } else {
      this.router.navigate(['/login']);
    }
  }

  /**
   * Refresh token
   */
  refreshToken(): Observable<AuthResponse> {
    return this.http.post<AuthResponse>('/api/auth/refresh', {})
      .pipe(
        tap(response => {
          localStorage.setItem('authToken', response.token);
          if (response.user) {
            localStorage.setItem('user', JSON.stringify(response.user));
          }
        }),
        catchError(error => {
          console.error('Token refresh failed:', error);
          return throwError(() => error);
        })
      );
  }

  /**
   * Handle successful authentication
   */
  private handleAuthSuccess(response: AuthResponse): void {
    if (response.token && response.user) {
      this.setAuthenticated(response.token, response.user);
    } else {
      console.error('Invalid auth response:', response);
      throw new Error('Invalid authentication response');
    }
  }

  /**
   * Handle errors
   */
  private handleError(error: any): Observable<never> {
    console.error('Auth error:', error);
    
    let errorMessage = 'An error occurred';
    
    if (error.error?.message) {
      errorMessage = error.error.message;
    } else if (error.message) {
      errorMessage = error.message;
    }
    
    return throwError(() => ({
      message: errorMessage,
      error: error
    }));
  }
}
