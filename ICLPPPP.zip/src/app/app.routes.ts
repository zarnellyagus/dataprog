import { Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ReportsComponent } from './components/reports/reports.component';
import { NewBusinessComponent } from './components/newbusiness/new-business.component';
import { NewBusinessFormComponent } from './components/new-business-input/new-business-form.component';


export const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { 
    path: 'dashboard', 
    component: DashboardComponent,
    children: [
      { path: 'reports', component: ReportsComponent },
      { path: 'reports/:type', component: ReportsComponent },
         { path: 'newbusiness', component: NewBusinessComponent },
           { path: 'new-business-input', component: NewBusinessFormComponent }
    ]
  },
  { path: '**', redirectTo: '/login' }
];
