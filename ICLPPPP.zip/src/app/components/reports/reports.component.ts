import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

interface Tab {
  id: string;
  label: string;
}

@Component({
  selector: 'app-reports',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit {
  activeTab = 'sekilas-bisnis';

  tabs: Tab[] = [
    { id: 'sekilas-bisnis', label: 'Sekilas bisnis' },
    { id: 'penjualan', label: 'Penjualan' },
    { id: 'pembelian', label: 'Pembelian' },
    { id: 'produk', label: 'Produk' },
    { id: 'aset', label: 'Aset' },
    { id: 'bank', label: 'Bank' },
    { id: 'pajak', label: 'Pajak' },
    { id: 'produksi', label: 'Produksi' }
  ];

  constructor(private router: Router) {}

  ngOnInit(): void {
    // Load saved tab from localStorage if exists
    const savedTab = localStorage.getItem('activeReportTab');
    if (savedTab) {
      this.activeTab = savedTab;
    }
  }

  switchTab(tabId: string): void {
    this.activeTab = tabId;
    // Save active tab to localStorage
    localStorage.setItem('activeReportTab', tabId);
    console.log('Switched to tab:', tabId);
  }

  viewReport(reportType: string): void {
    console.log('Viewing report:', reportType);
    // Navigate to specific report page
    this.router.navigate(['/reports', reportType]);
  }
}
