import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PolicySelectDialogComponent } from './policy-select-dialog.component';

describe('PolicySelectDialogComponent', () => {
  let component: PolicySelectDialogComponent;
  let fixture: ComponentFixture<PolicySelectDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PolicySelectDialogComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PolicySelectDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
