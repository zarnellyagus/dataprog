import { Component, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

export interface PolicyItem {
  policyNo: string;
  owner: string;
  productType: string;
}

@Component({
  selector: 'app-policy-select-dialog',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './policy-select-dialog.component.html',
  styleUrls: ['./policy-select-dialog.component.css']
})
export class PolicySelectDialogComponent {
  policies: PolicyItem[] = [
    { policyNo: 'POL-001', owner: 'John Doe',  productType: 'Life' },
    { policyNo: 'POL-002', owner: 'Jane Smith', productType: 'Health' },
    { policyNo: 'POL-003', owner: 'Acme Corp', productType: 'Group Life' }
  ];

  constructor(
    private dialogRef: MatDialogRef<PolicySelectDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  select(policy: PolicyItem): void {
    this.dialogRef.close(policy);
  }

  close(): void {
    this.dialogRef.close();
  }
}
