import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormsModule,
  ReactiveFormsModule,
  FormBuilder,
  FormGroup
} from '@angular/forms';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import {
  PolicySelectDialogComponent,
  PolicyItem
} from '../policy-select-dialog/policy-select-dialog.component';
import {
  InsuredSelectDialogComponent,
  InsuredItem
} from '../insured-select-dialog/insured-select-dialog.component';

@Component({
  selector: 'app-new-business-form',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule
  ],
  templateUrl: './new-business-form.component.html',
  styleUrls: ['./new-business-form.component.css']
})
export class NewBusinessFormComponent {
  form: FormGroup;

  constructor(
    private fb: FormBuilder,
    private dialog: MatDialog
  ) {
    this.form = this.fb.group({
      // Policy Information
      policyNo: [''],
      ownerName: [''],
      productType: [''],

      // Client - Insured
      insuredName: [''],
      insuredDob: [''],
      insuredSex: [''],
      insuredId: [''],
      insuredAltId: [''],

      // Client - Debitur
      isInsuredAsDebitur: [false],
      debiturName: [''],
      debiturDob: [''],
      debiturSex: [''],
      debiturId: [''],
      debiturAltId: [''],

      // Agent Information
      agentId: [''],
      agentName: [''],
      branchName: [''],
      mainBranchName: [''],
      areaName: [''],
      credamName: ['']
    });
  }

  // === Dialog pilih Policy ===
  openPolicyDialog(): void {
    const dialogRef = this.dialog.open(PolicySelectDialogComponent, {
      width: '600px',
      disableClose: true
    });

    dialogRef.afterClosed().subscribe((result: PolicyItem | undefined) => {
      if (result) {
        this.form.patchValue({
          policyNo: result.policyNo,
          ownerName: result.owner,
          productType: result.productType
        });
      }
    });
  }

  // === Dialog pilih Insured ===
  openInsuredDialog(): void {
    const keyword = this.form.get('insuredName')?.value || '';

    const dialogRef = this.dialog.open(InsuredSelectDialogComponent, {
      width: '900px',
      data: { keyword }
    });

    dialogRef.afterClosed().subscribe((result: InsuredItem | undefined) => {
      if (result) {
        this.form.patchValue({
          insuredName: result.insuredName,
          insuredId: result.insuredId,
          insuredSex: result.sex
        });
      }
    });
  }

  // === Submit form ===
  onSubmit(): void {
    if (this.form.valid) {
      console.log('New Business form value:', this.form.value);
    } else {
      this.form.markAllAsTouched();
    }
  }

  // === Find Client pakai dialog insured ===
  findClient(type: 'insured' | 'debitur'): void {
    if (type === 'insured') {
      this.openInsuredDialog();
    } else {
      // nanti bisa dibuat dialog khusus debitur
      console.log('Find client debitur belum diimplementasi');
    }
  }

  viewDetail(type: 'insured' | 'debitur'): void {
    console.log('View detail clicked:', type);
  }
}
