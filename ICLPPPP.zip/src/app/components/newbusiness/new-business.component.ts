import { Component, OnInit } from '@angular/core';
import { inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';


interface NewBusiness {
  id: string;
  tanggal: Date;
  nomor: string;
  memo: string;
  kontak: string;
  tglJatuhTempo: Date;
  status: 'Active' | 'Pending' | 'Processing' | 'Rejected';
  sisaTagihan: number;
  total: number;
  tags: string[];
}

@Component({
  selector: 'app-new-business',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    MatIconModule,
        RouterModule
  ],
  templateUrl: './new-business.component.html',
  styleUrls: ['./new-business.component.css']
})
export class NewBusinessComponent implements OnInit {
  // Filter properties
  filterStartDate = '2026-02-18';
  filterEndDate = '2026-02-18';
  filterTransactionType = '';
  searchText = '';
private router = inject(Router);
  // Sorting
  sortColumn = '';
  sortDirection: 'asc' | 'desc' = 'asc';

  // Pagination
  currentPage = 1;
  itemsPerPage = 10;
  totalPages = 1;

  // Data
  businessList: NewBusiness[] = [];
  filteredBusinessList: NewBusiness[] = [];

createNewBusiness(): void {
  console.log('Creating new business...');
  // Route harus sesuai dengan routes configuration
  this.router.navigate(['/dashboard/new-business-input']);
}
  ngOnInit(): void {
    this.loadNewBusinessData();
  }

  loadNewBusinessData(): void {
    // Sample data - replace with API call
    this.businessList = [
      {
        id: '1',
        tanggal: new Date('2026-02-18'),
        nomor: 'NB-2026-001',
        memo: 'Asuransi Jiwa Individual',
        kontak: 'Ahmad Ridwan',
        tglJatuhTempo: new Date('2026-03-18'),
        status: 'Active',
        sisaTagihan: 0,
        total: 15000000,
        tags: ['Life Insurance', 'Individual']
      },
      {
        id: '2',
        tanggal: new Date('2026-02-17'),
        nomor: 'NB-2026-002',
        memo: 'Asuransi Kesehatan Keluarga',
        kontak: 'Siti Nurhaliza',
        tglJatuhTempo: new Date('2026-03-17'),
        status: 'Pending',
        sisaTagihan: 8000000,
        total: 8000000,
        tags: ['Health', 'Family']
      },
      {
        id: '3',
        tanggal: new Date('2026-02-16'),
        nomor: 'NB-2026-003',
        memo: 'Asuransi Kendaraan',
        kontak: 'Budi Santoso',
        tglJatuhTempo: new Date('2026-03-16'),
        status: 'Processing',
        sisaTagihan: 5000000,
        total: 5000000,
        tags: ['Vehicle', 'Comprehensive']
      },
      {
        id: '4',
        tanggal: new Date('2026-02-15'),
        nomor: 'NB-2026-004',
        memo: 'Asuransi Properti',
        kontak: 'Dewi Lestari',
        tglJatuhTempo: new Date('2026-03-15'),
        status: 'Active',
        sisaTagihan: 0,
        total: 25000000,
        tags: ['Property', 'Fire']
      },
      {
        id: '5',
        tanggal: new Date('2026-02-14'),
        nomor: 'NB-2026-005',
        memo: 'Asuransi Perjalanan',
        kontak: 'Eko Prasetyo',
        tglJatuhTempo: new Date('2026-03-14'),
        status: 'Rejected',
        sisaTagihan: 2000000,
        total: 2000000,
        tags: ['Travel', 'International']
      },
      {
        id: '6',
        tanggal: new Date('2026-02-13'),
        nomor: 'NB-2026-006',
        memo: 'Asuransi Pendidikan',
        kontak: 'Fitri Handayani',
        tglJatuhTempo: new Date('2026-03-13'),
        status: 'Active',
        sisaTagihan: 0,
        total: 50000000,
        tags: ['Education', 'Long-term']
      },
      {
        id: '7',
        tanggal: new Date('2026-02-12'),
        nomor: 'NB-2026-007',
        memo: 'Asuransi Kecelakaan Diri',
        kontak: 'Gunawan Wijaya',
        tglJatuhTempo: new Date('2026-03-12'),
        status: 'Pending',
        sisaTagihan: 3500000,
        total: 3500000,
        tags: ['Accident', 'Personal']
      },
      {
        id: '8',
        tanggal: new Date('2026-02-11'),
        nomor: 'NB-2026-008',
        memo: 'Asuransi Investasi',
        kontak: 'Hendra Kurniawan',
        tglJatuhTempo: new Date('2026-03-11'),
        status: 'Processing',
        sisaTagihan: 100000000,
        total: 100000000,
        tags: ['Investment', 'Unit-link']
      },
      {
        id: '9',
        tanggal: new Date('2026-02-10'),
        nomor: 'NB-2026-009',
        memo: 'Asuransi Karyawan Group',
        kontak: 'PT Sejahtera Bersama',
        tglJatuhTempo: new Date('2026-03-10'),
        status: 'Active',
        sisaTagihan: 0,
        total: 75000000,
        tags: ['Group', 'Employee']
      },
      {
        id: '10',
        tanggal: new Date('2026-02-09'),
        nomor: 'NB-2026-010',
        memo: 'Asuransi Kredit',
        kontak: 'Indra Gunawan',
        tglJatuhTempo: new Date('2026-03-09'),
        status: 'Pending',
        sisaTagihan: 12000000,
        total: 12000000,
        tags: ['Credit', 'Mortgage']
      }
    ];

    this.filteredBusinessList = [...this.businessList];
    this.calculatePagination();
  }

  applyFilter(): void {
    this.filteredBusinessList = this.businessList.filter(business => {
      const businessDate = new Date(business.tanggal);
      const startDate = this.filterStartDate ? new Date(this.filterStartDate) : null;
      const endDate = this.filterEndDate ? new Date(this.filterEndDate) : null;

      if (startDate && businessDate < startDate) return false;
      if (endDate && businessDate > endDate) return false;

      if (this.searchText) {
        const searchLower = this.searchText.toLowerCase();
        return (
          business.nomor.toLowerCase().includes(searchLower) ||
          business.memo.toLowerCase().includes(searchLower) ||
          business.kontak.toLowerCase().includes(searchLower) ||
          business.status.toLowerCase().includes(searchLower)
        );
      }

      return true;
    });

    this.currentPage = 1;
    this.calculatePagination();
  }

  resetFilter(): void {
    this.filterStartDate = '';
    this.filterEndDate = '';
    this.filterTransactionType = '';
    this.searchText = '';
    this.filteredBusinessList = [...this.businessList];
    this.calculatePagination();
  }

  onSearch(): void {
    this.applyFilter();
  }

  sortBy(column: string): void {
    if (this.sortColumn === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumn = column;
      this.sortDirection = 'asc';
    }

    this.filteredBusinessList.sort((a, b) => {
      let aValue: any;
      let bValue: any;

      switch (column) {
        case 'tanggal':
          aValue = a.tanggal.getTime();
          bValue = b.tanggal.getTime();
          break;
        case 'nomor':
          aValue = a.nomor;
          bValue = b.nomor;
          break;
        case 'kontak':
          aValue = a.kontak;
          bValue = b.kontak;
          break;
        case 'status':
          aValue = a.status;
          bValue = b.status;
          break;
        default:
          return 0;
      }

      if (aValue < bValue) return this.sortDirection === 'asc' ? -1 : 1;
      if (aValue > bValue) return this.sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
  }

  calculatePagination(): void {
    this.totalPages = Math.ceil(this.filteredBusinessList.length / this.itemsPerPage);
  }

  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
    }
  }
}
