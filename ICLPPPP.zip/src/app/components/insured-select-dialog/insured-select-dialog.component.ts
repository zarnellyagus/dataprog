// insured-select-dialog.component.ts
import { Component, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

export interface InsuredItem {
  policyNo: string;
  insuredName: string;
  insuredId: string;
  sex: 'M' | 'F';
}

@Component({
  selector: 'app-insured-select-dialog',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './insured-select-dialog.component.html',
  styleUrls: ['./insured-select-dialog.component.css']
})
export class InsuredSelectDialogComponent {

  allInsured: InsuredItem[] = [
    { policyNo: '001', insuredName: 'Budi Santoso',  insuredId: 'ID001', sex: 'M' },
    { policyNo: '002', insuredName: 'Siti Aminah',   insuredId: 'ID002', sex: 'F' },
    { policyNo: '003', insuredName: 'Andi Wijaya',   insuredId: 'ID003', sex: 'M' },
    { policyNo: '004', insuredName: 'Ani Lestari',   insuredId: 'ID004', sex: 'F' }
  ];

  filteredInsured: InsuredItem[] = [];

  // field untuk input search (dua arah dengan ngModel)
  searchPolicy = '';
  searchName = '';

  constructor(
    private dialogRef: MatDialogRef<InsuredSelectDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { keyword: string }
  ) {
    // default: semua data
    this.filteredInsured = this.allInsured;

    // jika ada keyword dari insuredName di form, pakai sebagai search name awal
    if (data?.keyword) {
      this.searchName = data.keyword;
      this.applyFilter();
    }
  }

  applyFilter(): void {
    const policy = this.searchPolicy.toLowerCase().trim();
    const name = this.searchName.toLowerCase().trim();

    this.filteredInsured = this.allInsured.filter(i => {
      const matchPolicy = policy
        ? i.policyNo.toLowerCase().includes(policy)
        : true;
      const matchName = name
        ? i.insuredName.toLowerCase().includes(name)
        : true;
      return matchPolicy && matchName;
    });
  }

  selectRow(item: InsuredItem): void {
    this.dialogRef.close(item);
  }

  close(): void {
    this.dialogRef.close();
  }
}
