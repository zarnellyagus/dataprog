import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, RouterModule, ActivatedRoute } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule, 
    FormsModule, 
    ReactiveFormsModule,
    RouterModule,
    MatIconModule
  ],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  private authService = inject(AuthService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private fb = inject(FormBuilder);

  loginForm!: FormGroup;
  isLoading = false;
  errorMessage = '';
  activeTab: 'login' | 'register' = 'login';
  ssoFailed = false;

  ngOnInit(): void {
    // Check for SSO error messages
    this.route.queryParams.subscribe(params => {
      if (params['error']) {
        this.ssoFailed = true;
        switch (params['error']) {
          case 'sso_failed':
            this.errorMessage = 'SSO authentication failed. Please use manual login with username "admin" and password "admin".';
            break;
          case 'invalid_sso_response':
            this.errorMessage = 'Invalid SSO response. Please use manual login.';
            break;
          case 'sso_redirect_failed':
            this.errorMessage = 'Failed to connect to SSO. Please use manual login.';
            break;
        }
      }
    });

    // Redirect if already authenticated
    if (this.authService.isAuthenticated()) {
      this.router.navigate(['/dashboard']);
      return;
    }

    this.initializeForm();
  }

  initializeForm(): void {
    this.loginForm = this.fb.group({
      username: ['', [Validators.required, Validators.minLength(3)]],
      password: ['', [Validators.required, Validators.minLength(3)]]
    });
  }

  switchTab(tab: 'login' | 'register'): void {
    this.activeTab = tab;
    this.errorMessage = '';
  }

  onSubmit(): void {
    if (this.loginForm.invalid) {
      this.markFormGroupTouched(this.loginForm);
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';

    const { username, password } = this.loginForm.value;

    console.log('Attempting login with:', username);

    this.authService.login(username, password).subscribe({
      next: (response) => {
        this.isLoading = false;
        console.log('Login successful:', response);
        // Navigation handled by authService.setAuthenticated
      },
      error: (error) => {
        this.isLoading = false;
        console.error('Login error:', error);
        this.errorMessage = error.message || 'Login failed. Try username: "admin", password: "admin"';
      }
    });
  }

  loginWithAzureSSO(): void {
    this.isLoading = true;
    this.errorMessage = '';
    this.ssoFailed = false;
    
    // Small delay to show loading state
    setTimeout(() => {
      this.authService.loginWithAzureSSO();
    }, 300);
  }

  private markFormGroupTouched(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach(key => {
      const control = formGroup.get(key);
      control?.markAsTouched();
    });
  }

  getErrorMessage(fieldName: string): string {
    const control = this.loginForm.get(fieldName);
    
    if (control?.hasError('required')) {
      return `${fieldName.charAt(0).toUpperCase() + fieldName.slice(1)} is required`;
    }
    
    if (control?.hasError('minlength')) {
      const requiredLength = control.errors?.['minlength'].requiredLength;
      return `${fieldName.charAt(0).toUpperCase() + fieldName.slice(1)} must be at least ${requiredLength} characters`;
    }
    
    return '';
  }
}
