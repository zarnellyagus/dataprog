import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatListModule } from '@angular/material/list';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatMenuModule,} from '@angular/material/menu';   // ← tambah

import { RouterModule,Router  } from '@angular/router';

interface MenuItem {
  icon?: string;
  label: string;
  route?: string;
  badge?: number;
  children?: MenuItem[];
  expanded?: boolean;
  isHeader?: boolean;  // ← tambah properti ini
}

interface SaleItem {
  name: string;
  value: number;
  percent: number;
  color: string;
}

interface EarningItem {
  label: string;
  value: string;
  trend: number;
  trendUp: boolean;
}

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    MatToolbarModule,
    MatSidenavModule,
    MatIconModule,
    MatButtonModule,
    MatListModule,
    MatProgressBarModule,
     MatMenuModule,   // ← tambah
    RouterModule
  ],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent {
  sidenavOpened = true;
  activeTab = 'Month';
   constructor(private router: Router) {}
   currentUser = {
    name: 'John Doe',
    email: 'johndoe@example.com',
    avatar: 'account_circle'
  };

  logout(): void {
    // Bersihkan session/token jika ada
    localStorage.removeItem('token');
    sessionStorage.clear();
    // Redirect ke halaman login
    this.router.navigate(['/login']);
  }
menuItems: MenuItem[] = [
  { icon: 'dashboard', label: 'Dashboard', route: '/dashboard' },

  // Header Policy & Certificate
  { label: 'Policy & Certificate', isHeader: true },
  { icon: 'list_alt',        label: 'Certificate List', route: '/certificate/list' },
  { icon: 'fiber_new',       label: 'New Business',     route: '/certificate/new-business' },
  { icon: 'verified_user',   label: 'Underwriting',     route: '/certificate/underwriting' },
  { icon: 'manage_accounts', label: 'Policy Admin',     route: '/certificate/policy-admin' },

  // Header Aktivitas
  { label: 'Aktivitas', isHeader: true },
  { icon: 'receipt_long', label: 'Billing', route: '/aktivitas/billing' },

  { label: 'Reports', isHeader: true },
  { icon: 'receipt_long', label: 'Billing', route: '/aktivitas/billing' }
];

  stats = [
    { label: 'Total Sales',     value: 25140,  income: '$22,506', trend: 10.25, icon: 'shopping_cart', colorClass: 'purple' },
    { label: 'New Orders',      value: 65241,  income: '$22,506', trend: 10.25, icon: 'sync',          colorClass: 'gray'   },
    { label: 'New Users',       value: 85412,  income: '$22,506', trend: 10.25, icon: 'layers',        colorClass: 'brown'  },
    { label: 'Unique Visitors', value: 20544,  income: '$22,506', trend: 10.25, icon: 'local_cafe',    colorClass: 'teal'   }
  ];

  earnings: EarningItem[] = [
    { label: 'Weekly Earnings',  value: '$1,542',  trend: 8.4,  trendUp: true  },
    { label: 'Monthly Earnings', value: '$6,451',  trend: 5.2,  trendUp: true  },
    { label: 'Yearly Earnings',  value: '$84,574', trend: 12.7, trendUp: true  }
  ];

  salesItems: SaleItem[] = [
    { name: 'SonyVaio', value: 44, percent: 44, color: '#6c63ff' },
    { name: 'iMacs',    value: 27, percent: 27, color: '#4bcffa' },
    { name: 'Tablets',  value: 36, percent: 36, color: '#f9ca24' },
    { name: 'iPhones',  value: 22, percent: 22, color: '#e84393' },
    { name: 'Macbooks', value: 48, percent: 48, color: '#4b7bec' }
  ];

  salesAnalytics = [
    { label: 'Desktops', percent: 44, color: '#5B5EA6' },
    { label: 'Mobiles',  percent: 43, color: '#4bcffa' },
    { label: 'Tablets',  percent: 13, color: '#43d787' }
  ];

  activatedCount = 25610;
  pendingCount   = 56210;

  recentOrders = [
    { id: '#1001', product: 'MacBook Pro',  customer: 'John Doe',   amount: '$1,299', status: 'Completed' },
    { id: '#1002', product: 'Sony Vaio',    customer: 'Jane Smith', amount: '$899',   status: 'Pending'   },
    { id: '#1003', product: 'iPad Tablet',  customer: 'Bob Wilson', amount: '$649',   status: 'Completed' },
    { id: '#1004', product: 'iPhone 15',    customer: 'Alice Brown',amount: '$999',   status: 'Processing'},
    { id: '#1005', product: 'iMac 27"',     customer: 'Tom Clark',  amount: '$1,799', status: 'Completed' }
  ];

  toggleSidenav(): void {
    this.sidenavOpened = !this.sidenavOpened;
  }

  toggleMenuItem(item: MenuItem): void {
    if (item.children) {
      item.expanded = !item.expanded;
    }
  }
}
